<?php
declare(strict_types=1);
/**
 * SIGMU – Configuración y utilidades compartidas
 * Lo usan index.php e Informacion_Urbana.php (y las páginas siguientes).
 */

const DB_HOST = 'localhost';
const DB_NAME = 'sigmu_db';
const DB_USER = 'root';   // En producción usa un usuario con permisos mínimos (ver sigmu_db.sql)
const DB_PASS = '';

/** Escapa texto para HTML. */
function e(?string $v): string
{
    return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** Conexión PDO única; devuelve null si no hay base de datos. */
function db(): ?PDO
{
    static $pdo = null;
    static $intentado = false;
    if ($intentado) {
        return $pdo;
    }
    $intentado = true;
    try {
        $pdo = new PDO(
            'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
            DB_USER,
            DB_PASS,
            [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]
        );
    } catch (Throwable $ex) {
        $pdo = null;
    }
    return $pdo;
}

/** Normaliza un nombre de municipio: minúsculas, sin tildes, sin "D.C." ni puntuación. */
function norm(string $s): string
{
    $s = mb_strtolower(trim($s), 'UTF-8');
    $s = strtr($s, [
        'á' => 'a', 'é' => 'e', 'í' => 'i', 'ó' => 'o', 'ú' => 'u', 'ü' => 'u', 'ñ' => 'n',
    ]);
    $s = preg_replace('/distrito capital/', '', $s) ?? $s;
    $s = preg_replace('/\bd\.\s?c\.?/', '', $s) ?? $s;
    $s = preg_replace('/[^a-z0-9 ]/', ' ', $s) ?? $s;
    return trim(preg_replace('/\s+/', ' ', $s) ?? $s);
}

/** Distancia en metros entre dos coordenadas (Haversine). */
function haversine_m(float $la1, float $lo1, float $la2, float $lo2): float
{
    $R = 6371000.0;
    $dLa = deg2rad($la2 - $la1);
    $dLo = deg2rad($lo2 - $lo1);
    $h = sin($dLa / 2) ** 2 + cos(deg2rad($la1)) * cos(deg2rad($la2)) * sin($dLo / 2) ** 2;
    return 2 * $R * asin(min(1.0, sqrt($h)));
}