-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 19-10-2026 a las 06:15:03
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sigmu_db`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `buses`
--

CREATE TABLE `buses` (
  `id` int(10) UNSIGNED NOT NULL,
  `empresa_id` int(10) UNSIGNED DEFAULT NULL,
  `placa` varchar(10) NOT NULL,
  `numero_interno` varchar(20) DEFAULT NULL,
  `marca` varchar(60) DEFAULT NULL,
  `modelo` varchar(60) DEFAULT NULL,
  `anio` smallint(5) UNSIGNED DEFAULT NULL,
  `capacidad_sentados` smallint(5) UNSIGNED DEFAULT NULL,
  `capacidad_de_pie` smallint(5) UNSIGNED DEFAULT NULL,
  `accesible` tinyint(1) DEFAULT NULL,
  `aire_acondicionado` tinyint(1) DEFAULT NULL,
  `estado` enum('disponible','en_servicio','mantenimiento','fuera_servicio') NOT NULL DEFAULT 'disponible',
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `calificaciones`
--

CREATE TABLE `calificaciones` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ruta_id` int(10) UNSIGNED NOT NULL,
  `bus_id` int(10) UNSIGNED DEFAULT NULL,
  `conductor_id` int(10) UNSIGNED DEFAULT NULL,
  `usuario_id` int(10) UNSIGNED DEFAULT NULL,
  `sesion_hash` char(64) DEFAULT NULL,
  `puntaje` tinyint(3) UNSIGNED NOT NULL,
  `comentario` varchar(500) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp()
) ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias_ruta`
--

CREATE TABLE `categorias_ruta` (
  `id` int(10) UNSIGNED NOT NULL,
  `codigo` enum('municipal','intermunicipal','otros') NOT NULL,
  `nombre` varchar(60) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `orden` tinyint(3) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `categorias_ruta`
--

INSERT INTO `categorias_ruta` (`id`, `codigo`, `nombre`, `descripcion`, `orden`) VALUES
(1, 'municipal', 'Municipales', 'Rutas que operan dentro de un mismo municipio.', 1),
(2, 'intermunicipal', 'Intermunicipales', 'Rutas que conectan dos o más municipios.', 2),
(3, 'otros', 'Otros', 'Servicios especiales: escolar, laboral u otros.', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `conductores`
--

CREATE TABLE `conductores` (
  `id` int(10) UNSIGNED NOT NULL,
  `empresa_id` int(10) UNSIGNED DEFAULT NULL,
  `usuario_id` int(10) UNSIGNED DEFAULT NULL,
  `nombres` varchar(100) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `foto_url` varchar(255) DEFAULT NULL,
  `anios_experiencia` tinyint(3) UNSIGNED DEFAULT NULL,
  `documento` varchar(30) DEFAULT NULL,
  `licencia_numero` varchar(30) DEFAULT NULL,
  `licencia_categoria` varchar(10) DEFAULT NULL,
  `licencia_vence` date DEFAULT NULL,
  `telefono` varchar(30) DEFAULT NULL,
  `estado` enum('activo','inactivo','suspendido') NOT NULL DEFAULT 'activo',
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `contenido_sistema`
--

CREATE TABLE `contenido_sistema` (
  `id` int(10) UNSIGNED NOT NULL,
  `clave` enum('mision','bienvenida','vision','informacion') NOT NULL,
  `titulo` varchar(120) NOT NULL,
  `texto` text NOT NULL,
  `icono` varchar(10) NOT NULL DEFAULT '?',
  `orden` tinyint(3) UNSIGNED NOT NULL DEFAULT 1,
  `activo` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `contenido_sistema`
--

INSERT INTO `contenido_sistema` (`id`, `clave`, `titulo`, `texto`, `icono`, `orden`, `activo`) VALUES
(1, 'mision', 'Nuestra Misión', 'Mejorar la experiencia y la seguridad del transporte público en Bogotá con un sistema híbrido de información en tiempo real: app con GPS del conductor, panel en el paradero y avisos sin internet (SMS/BLE).', '🎯', 1, 1),
(2, 'bienvenida', '¡Bienvenidos a SIGMU!', 'Consulta buses, horarios y paraderos cercanos, y conoce en qué municipio y barrio te encuentras, todo desde un solo lugar.', '🚌', 2, 1),
(3, 'vision', 'Nuestra Visión', 'Ser un referente de movilidad inteligente e incluyente en Colombia, con paraderos bien iluminados, señalizados y seguros para todas las personas.', '🌟', 3, 1),
(4, 'informacion', 'Información del Sistema', 'SIGMU combina geolocalización, mapas y datos de paraderos y rutas. También funciona para quienes no tienen conexión estable a internet.', '📡', 4, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empresas_transporte`
--

CREATE TABLE `empresas_transporte` (
  `id` int(10) UNSIGNED NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `nit` varchar(30) DEFAULT NULL,
  `telefono` varchar(30) DEFAULT NULL,
  `correo` varchar(150) DEFAULT NULL,
  `direccion` varchar(200) DEFAULT NULL,
  `estado` enum('activa','inactiva') NOT NULL DEFAULT 'activa',
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `horarios`
--

CREATE TABLE `horarios` (
  `id` int(10) UNSIGNED NOT NULL,
  `ruta_id` int(10) UNSIGNED NOT NULL,
  `paradero_id` int(10) UNSIGNED NOT NULL,
  `dia_tipo` enum('LV','SAB','DOM') NOT NULL DEFAULT 'LV',
  `hora_salida` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `horarios`
--

INSERT INTO `horarios` (`id`, `ruta_id`, `paradero_id`, `dia_tipo`, `hora_salida`) VALUES
(1, 1, 1, 'LV', '05:30:00'),
(2, 1, 1, 'LV', '06:00:00'),
(3, 1, 1, 'LV', '06:30:00'),
(4, 1, 1, 'LV', '12:00:00'),
(5, 1, 1, 'LV', '18:00:00'),
(6, 1, 1, 'LV', '21:00:00'),
(7, 2, 3, 'LV', '05:45:00'),
(8, 2, 3, 'LV', '06:15:00'),
(9, 2, 3, 'LV', '12:30:00'),
(10, 2, 3, 'LV', '17:30:00'),
(11, 2, 3, 'LV', '20:30:00'),
(12, 3, 2, 'LV', '06:00:00'),
(13, 3, 2, 'LV', '06:30:00'),
(14, 3, 2, 'LV', '13:00:00'),
(15, 3, 2, 'LV', '19:00:00'),
(16, 4, 7, 'LV', '05:15:00'),
(17, 4, 7, 'LV', '07:00:00'),
(18, 4, 7, 'LV', '15:00:00'),
(19, 4, 7, 'LV', '19:30:00'),
(20, 1, 1, 'SAB', '06:00:00'),
(21, 1, 1, 'SAB', '10:00:00'),
(22, 1, 1, 'SAB', '16:00:00'),
(23, 2, 3, 'SAB', '07:00:00'),
(24, 3, 2, 'SAB', '08:00:00'),
(25, 4, 7, 'SAB', '07:30:00'),
(26, 1, 1, 'DOM', '07:00:00'),
(27, 1, 1, 'DOM', '14:00:00'),
(28, 2, 3, 'DOM', '09:00:00'),
(29, 4, 7, 'DOM', '09:30:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `municipios`
--

CREATE TABLE `municipios` (
  `id` int(10) UNSIGNED NOT NULL,
  `nombre` varchar(120) NOT NULL,
  `departamento` varchar(120) NOT NULL,
  `latitud` decimal(10,7) NOT NULL,
  `longitud` decimal(10,7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `municipios`
--

INSERT INTO `municipios` (`id`, `nombre`, `departamento`, `latitud`, `longitud`) VALUES
(1, 'Bogotá D.C.', 'Cundinamarca', 4.7109886, -74.0721092),
(2, 'Zipaquirá', 'Cundinamarca', 5.0220000, -74.0050000),
(3, 'Soacha', 'Cundinamarca', 4.5794000, -74.2168000),
(4, 'Chía', 'Cundinamarca', 4.8587000, -74.0586000),
(5, 'Cajicá', 'Cundinamarca', 4.9186000, -74.0277000);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paraderos`
--

CREATE TABLE `paraderos` (
  `id` int(10) UNSIGNED NOT NULL,
  `codigo` varchar(20) NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `direccion` varchar(200) NOT NULL,
  `municipio_id` int(10) UNSIGNED NOT NULL,
  `sector` varchar(120) DEFAULT NULL,
  `latitud` decimal(10,7) NOT NULL,
  `longitud` decimal(10,7) NOT NULL,
  `tiene_iluminacion` tinyint(1) NOT NULL DEFAULT 0,
  `tiene_senalizacion` tinyint(1) NOT NULL DEFAULT 0,
  `estado` enum('activo','mantenimiento','inactivo') NOT NULL DEFAULT 'activo',
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `paraderos`
--

INSERT INTO `paraderos` (`id`, `codigo`, `nombre`, `direccion`, `municipio_id`, `sector`, `latitud`, `longitud`, `tiene_iluminacion`, `tiene_senalizacion`, `estado`, `creado_en`) VALUES
(1, 'PAR-001', 'Portal Norte', 'Autopista Norte con Calle 170', 1, 'Usaquén', 4.7545000, -74.0457000, 1, 1, 'activo', '2026-10-19 04:04:24'),
(2, 'PAR-002', 'Calle 100', 'Autopista Norte con Calle 100', 1, 'Chicó', 4.6862000, -74.0576000, 1, 1, 'activo', '2026-10-19 04:04:24'),
(3, 'PAR-003', 'Plaza de Bolívar', 'Carrera 7 con Calle 11', 1, 'La Candelaria', 4.5981000, -74.0760000, 1, 0, 'activo', '2026-10-19 04:04:24'),
(4, 'PAR-004', 'Terminal Salitre', 'Avenida Calle 26 con Carrera 68', 1, 'Salitre', 4.6490000, -74.1170000, 1, 1, 'activo', '2026-10-19 04:04:24'),
(5, 'PAR-005', 'Portal 80', 'Avenida Calle 80 con Carrera 100', 1, 'Engativá', 4.7208000, -74.1122000, 0, 1, 'mantenimiento', '2026-10-19 04:04:24'),
(6, 'PAR-006', 'Portal Sur', 'Autopista Sur con Carrera 72', 1, 'Ciudad Bolívar', 4.5948000, -74.1925000, 1, 1, 'activo', '2026-10-19 04:04:24'),
(7, 'PAR-007', 'Parque Principal Zipaquirá', 'Centro de Zipaquirá', 2, 'Centro', 5.0229000, -74.0048000, 1, 1, 'activo', '2026-10-19 04:04:24');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `posiciones_bus`
--

CREATE TABLE `posiciones_bus` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `bus_id` int(10) UNSIGNED NOT NULL,
  `turno_id` bigint(20) UNSIGNED DEFAULT NULL,
  `latitud` decimal(10,7) NOT NULL,
  `longitud` decimal(10,7) NOT NULL,
  `velocidad_kmh` decimal(5,1) DEFAULT NULL,
  `rumbo_grados` smallint(5) UNSIGNED DEFAULT NULL,
  `precision_m` smallint(5) UNSIGNED DEFAULT NULL,
  `registrado_en` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reportes_seguridad`
--

CREATE TABLE `reportes_seguridad` (
  `id` int(10) UNSIGNED NOT NULL,
  `paradero_id` int(10) UNSIGNED NOT NULL,
  `usuario_id` int(10) UNSIGNED DEFAULT NULL,
  `tipo` enum('iluminacion','senalizacion','inseguridad','otro') NOT NULL,
  `descripcion` varchar(500) NOT NULL,
  `estado` enum('abierto','en_revision','resuelto') NOT NULL DEFAULT 'abierto',
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `reportes_seguridad`
--

INSERT INTO `reportes_seguridad` (`id`, `paradero_id`, `usuario_id`, `tipo`, `descripcion`, `estado`, `creado_en`) VALUES
(1, 5, NULL, 'iluminacion', 'Luminarias apagadas en el paradero durante la noche.', 'abierto', '2026-10-19 04:04:24'),
(2, 3, NULL, 'senalizacion', 'La señal del paradero está deteriorada y poco visible.', 'abierto', '2026-10-19 04:04:24');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rutas`
--

CREATE TABLE `rutas` (
  `id` int(10) UNSIGNED NOT NULL,
  `codigo` varchar(20) NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `origen` varchar(120) NOT NULL,
  `destino` varchar(120) NOT NULL,
  `categoria_id` int(10) UNSIGNED DEFAULT NULL,
  `tipo_servicio_id` int(10) UNSIGNED DEFAULT NULL,
  `empresa_id` int(10) UNSIGNED DEFAULT NULL,
  `descripcion` varchar(500) DEFAULT NULL,
  `hora_inicio` time DEFAULT NULL,
  `hora_fin` time DEFAULT NULL,
  `frecuencia_min` smallint(5) UNSIGNED DEFAULT NULL COMMENT 'Minutos entre buses',
  `estado` enum('activa','suspendida') NOT NULL DEFAULT 'activa'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `rutas`
--

INSERT INTO `rutas` (`id`, `codigo`, `nombre`, `origen`, `destino`, `categoria_id`, `tipo_servicio_id`, `empresa_id`, `descripcion`, `hora_inicio`, `hora_fin`, `frecuencia_min`, `estado`) VALUES
(1, 'SIG-01', 'Portal Norte – Portal Sur', 'Portal Norte', 'Portal Sur', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'activa'),
(2, 'SIG-02', 'Portal 80 – Plaza de Bolívar', 'Portal 80', 'Plaza de Bolívar', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'activa'),
(3, 'SIG-03', 'Terminal Salitre – Calle 100', 'Terminal Salitre', 'Calle 100', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'activa'),
(4, 'SIG-04', 'Zipaquirá – Portal Norte', 'Zipaquirá', 'Portal Norte', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'activa');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ruta_municipio`
--

CREATE TABLE `ruta_municipio` (
  `ruta_id` int(10) UNSIGNED NOT NULL,
  `municipio_id` int(10) UNSIGNED NOT NULL,
  `orden` tinyint(3) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ruta_paradero`
--

CREATE TABLE `ruta_paradero` (
  `ruta_id` int(10) UNSIGNED NOT NULL,
  `paradero_id` int(10) UNSIGNED NOT NULL,
  `orden` smallint(5) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `ruta_paradero`
--

INSERT INTO `ruta_paradero` (`ruta_id`, `paradero_id`, `orden`) VALUES
(1, 1, 1),
(1, 2, 2),
(1, 3, 3),
(1, 6, 4),
(2, 5, 1),
(2, 3, 2),
(3, 4, 1),
(3, 2, 2),
(4, 7, 1),
(4, 1, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ruta_trazado`
--

CREATE TABLE `ruta_trazado` (
  `id` int(10) UNSIGNED NOT NULL,
  `ruta_id` int(10) UNSIGNED NOT NULL,
  `orden` int(10) UNSIGNED NOT NULL,
  `latitud` decimal(10,7) NOT NULL,
  `longitud` decimal(10,7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tarifas`
--

CREATE TABLE `tarifas` (
  `id` int(10) UNSIGNED NOT NULL,
  `ruta_id` int(10) UNSIGNED NOT NULL,
  `concepto` varchar(80) NOT NULL,
  `valor_cop` decimal(10,2) NOT NULL,
  `vigente_desde` date NOT NULL,
  `vigente_hasta` date DEFAULT NULL
) ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos_servicio`
--

CREATE TABLE `tipos_servicio` (
  `id` int(10) UNSIGNED NOT NULL,
  `categoria_id` int(10) UNSIGNED NOT NULL,
  `nombre` varchar(80) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `tipos_servicio`
--

INSERT INTO `tipos_servicio` (`id`, `categoria_id`, `nombre`, `descripcion`) VALUES
(1, 3, 'Escolar', NULL),
(2, 3, 'Laboral', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `turnos`
--

CREATE TABLE `turnos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ruta_id` int(10) UNSIGNED NOT NULL,
  `bus_id` int(10) UNSIGNED NOT NULL,
  `conductor_id` int(10) UNSIGNED DEFAULT NULL,
  `fecha` date NOT NULL,
  `hora_salida` time NOT NULL,
  `hora_llegada_estimada` time DEFAULT NULL,
  `estado` enum('programado','en_curso','finalizado','cancelado') NOT NULL DEFAULT 'programado',
  `pasajeros_actuales` smallint(5) UNSIGNED DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ubicaciones_usuario`
--

CREATE TABLE `ubicaciones_usuario` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sesion_hash` char(64) NOT NULL,
  `latitud` decimal(10,7) NOT NULL,
  `longitud` decimal(10,7) NOT NULL,
  `precision_m` int(10) UNSIGNED DEFAULT NULL,
  `municipio` varchar(120) DEFAULT NULL,
  `barrio` varchar(120) DEFAULT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(10) UNSIGNED NOT NULL,
  `nombre` varchar(120) NOT NULL,
  `correo` varchar(150) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `rol` enum('usuario','conductor','admin') NOT NULL DEFAULT 'usuario',
  `telefono` varchar(20) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_paraderos_activos`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_paraderos_activos` (
`id` int(10) unsigned
,`codigo` varchar(20)
,`nombre` varchar(150)
,`direccion` varchar(200)
,`municipio` varchar(120)
,`sector` varchar(120)
,`latitud` decimal(10,7)
,`longitud` decimal(10,7)
,`tiene_iluminacion` tinyint(1)
,`tiene_senalizacion` tinyint(1)
,`estado` enum('activo','mantenimiento','inactivo')
);

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_paraderos_activos`
--
DROP TABLE IF EXISTS `vista_paraderos_activos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_paraderos_activos`  AS SELECT `p`.`id` AS `id`, `p`.`codigo` AS `codigo`, `p`.`nombre` AS `nombre`, `p`.`direccion` AS `direccion`, `m`.`nombre` AS `municipio`, `p`.`sector` AS `sector`, `p`.`latitud` AS `latitud`, `p`.`longitud` AS `longitud`, `p`.`tiene_iluminacion` AS `tiene_iluminacion`, `p`.`tiene_senalizacion` AS `tiene_senalizacion`, `p`.`estado` AS `estado` FROM (`paraderos` `p` join `municipios` `m` on(`m`.`id` = `p`.`municipio_id`)) WHERE `p`.`estado` <> 'inactivo' ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `buses`
--
ALTER TABLE `buses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_bus_placa` (`placa`),
  ADD KEY `idx_bus_empresa` (`empresa_id`);

--
-- Indices de la tabla `calificaciones`
--
ALTER TABLE `calificaciones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_cal_ruta` (`ruta_id`,`creado_en`),
  ADD KEY `idx_cal_bus` (`bus_id`),
  ADD KEY `idx_cal_conductor` (`conductor_id`),
  ADD KEY `idx_cal_sesion` (`sesion_hash`,`ruta_id`),
  ADD KEY `fk_cal_usuario` (`usuario_id`);

--
-- Indices de la tabla `categorias_ruta`
--
ALTER TABLE `categorias_ruta`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_categoria_codigo` (`codigo`);

--
-- Indices de la tabla `conductores`
--
ALTER TABLE `conductores`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_cond_empresa` (`empresa_id`),
  ADD KEY `fk_cond_usuario` (`usuario_id`);

--
-- Indices de la tabla `contenido_sistema`
--
ALTER TABLE `contenido_sistema`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_clave` (`clave`);

--
-- Indices de la tabla `empresas_transporte`
--
ALTER TABLE `empresas_transporte`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_empresa_nombre` (`nombre`);

--
-- Indices de la tabla `horarios`
--
ALTER TABLE `horarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_horario_busqueda` (`dia_tipo`,`hora_salida`),
  ADD KEY `fk_h_ruta` (`ruta_id`),
  ADD KEY `fk_h_paradero` (`paradero_id`);

--
-- Indices de la tabla `municipios`
--
ALTER TABLE `municipios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_municipio` (`nombre`,`departamento`);

--
-- Indices de la tabla `paraderos`
--
ALTER TABLE `paraderos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_paradero_codigo` (`codigo`),
  ADD KEY `idx_paradero_coord` (`latitud`,`longitud`),
  ADD KEY `fk_paradero_municipio` (`municipio_id`);

--
-- Indices de la tabla `posiciones_bus`
--
ALTER TABLE `posiciones_bus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_pos_bus_fecha` (`bus_id`,`registrado_en`),
  ADD KEY `fk_pos_turno` (`turno_id`);

--
-- Indices de la tabla `reportes_seguridad`
--
ALTER TABLE `reportes_seguridad`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_rs_paradero` (`paradero_id`),
  ADD KEY `fk_rs_usuario` (`usuario_id`);

--
-- Indices de la tabla `rutas`
--
ALTER TABLE `rutas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_ruta_codigo` (`codigo`),
  ADD KEY `idx_rutas_categoria` (`categoria_id`),
  ADD KEY `idx_rutas_empresa` (`empresa_id`),
  ADD KEY `fk_rutas_tipo` (`tipo_servicio_id`);

--
-- Indices de la tabla `ruta_municipio`
--
ALTER TABLE `ruta_municipio`
  ADD PRIMARY KEY (`ruta_id`,`municipio_id`),
  ADD KEY `idx_rm_municipio` (`municipio_id`);

--
-- Indices de la tabla `ruta_paradero`
--
ALTER TABLE `ruta_paradero`
  ADD PRIMARY KEY (`ruta_id`,`paradero_id`),
  ADD UNIQUE KEY `uq_ruta_orden` (`ruta_id`,`orden`),
  ADD KEY `fk_rp_paradero` (`paradero_id`);

--
-- Indices de la tabla `ruta_trazado`
--
ALTER TABLE `ruta_trazado`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_trazado_orden` (`ruta_id`,`orden`);

--
-- Indices de la tabla `tarifas`
--
ALTER TABLE `tarifas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_tarifa_ruta` (`ruta_id`,`vigente_desde`);

--
-- Indices de la tabla `tipos_servicio`
--
ALTER TABLE `tipos_servicio`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_tipo_servicio` (`categoria_id`,`nombre`);

--
-- Indices de la tabla `turnos`
--
ALTER TABLE `turnos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_turno_busqueda` (`ruta_id`,`fecha`,`estado`),
  ADD KEY `fk_turno_bus` (`bus_id`),
  ADD KEY `fk_turno_conductor` (`conductor_id`);

--
-- Indices de la tabla `ubicaciones_usuario`
--
ALTER TABLE `ubicaciones_usuario`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_ub_fecha` (`creado_en`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_usuario_correo` (`correo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `buses`
--
ALTER TABLE `buses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `calificaciones`
--
ALTER TABLE `calificaciones`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `categorias_ruta`
--
ALTER TABLE `categorias_ruta`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `conductores`
--
ALTER TABLE `conductores`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `contenido_sistema`
--
ALTER TABLE `contenido_sistema`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `empresas_transporte`
--
ALTER TABLE `empresas_transporte`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `horarios`
--
ALTER TABLE `horarios`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT de la tabla `municipios`
--
ALTER TABLE `municipios`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `paraderos`
--
ALTER TABLE `paraderos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `posiciones_bus`
--
ALTER TABLE `posiciones_bus`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `reportes_seguridad`
--
ALTER TABLE `reportes_seguridad`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `rutas`
--
ALTER TABLE `rutas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `ruta_trazado`
--
ALTER TABLE `ruta_trazado`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tarifas`
--
ALTER TABLE `tarifas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tipos_servicio`
--
ALTER TABLE `tipos_servicio`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `turnos`
--
ALTER TABLE `turnos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `ubicaciones_usuario`
--
ALTER TABLE `ubicaciones_usuario`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `buses`
--
ALTER TABLE `buses`
  ADD CONSTRAINT `fk_bus_empresa` FOREIGN KEY (`empresa_id`) REFERENCES `empresas_transporte` (`id`) ON DELETE SET NULL;

--
-- Filtros para la tabla `calificaciones`
--
ALTER TABLE `calificaciones`
  ADD CONSTRAINT `fk_cal_bus` FOREIGN KEY (`bus_id`) REFERENCES `buses` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_cal_conductor` FOREIGN KEY (`conductor_id`) REFERENCES `conductores` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_cal_ruta` FOREIGN KEY (`ruta_id`) REFERENCES `rutas` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_cal_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL;

--
-- Filtros para la tabla `conductores`
--
ALTER TABLE `conductores`
  ADD CONSTRAINT `fk_cond_empresa` FOREIGN KEY (`empresa_id`) REFERENCES `empresas_transporte` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_cond_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL;

--
-- Filtros para la tabla `horarios`
--
ALTER TABLE `horarios`
  ADD CONSTRAINT `fk_h_paradero` FOREIGN KEY (`paradero_id`) REFERENCES `paraderos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_h_ruta` FOREIGN KEY (`ruta_id`) REFERENCES `rutas` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `paraderos`
--
ALTER TABLE `paraderos`
  ADD CONSTRAINT `fk_paradero_municipio` FOREIGN KEY (`municipio_id`) REFERENCES `municipios` (`id`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `posiciones_bus`
--
ALTER TABLE `posiciones_bus`
  ADD CONSTRAINT `fk_pos_bus` FOREIGN KEY (`bus_id`) REFERENCES `buses` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_pos_turno` FOREIGN KEY (`turno_id`) REFERENCES `turnos` (`id`) ON DELETE SET NULL;

--
-- Filtros para la tabla `reportes_seguridad`
--
ALTER TABLE `reportes_seguridad`
  ADD CONSTRAINT `fk_rs_paradero` FOREIGN KEY (`paradero_id`) REFERENCES `paraderos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_rs_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL;

--
-- Filtros para la tabla `rutas`
--
ALTER TABLE `rutas`
  ADD CONSTRAINT `fk_rutas_categoria` FOREIGN KEY (`categoria_id`) REFERENCES `categorias_ruta` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_rutas_empresa` FOREIGN KEY (`empresa_id`) REFERENCES `empresas_transporte` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_rutas_tipo` FOREIGN KEY (`tipo_servicio_id`) REFERENCES `tipos_servicio` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `ruta_municipio`
--
ALTER TABLE `ruta_municipio`
  ADD CONSTRAINT `fk_rm_municipio` FOREIGN KEY (`municipio_id`) REFERENCES `municipios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_rm_ruta` FOREIGN KEY (`ruta_id`) REFERENCES `rutas` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `ruta_paradero`
--
ALTER TABLE `ruta_paradero`
  ADD CONSTRAINT `fk_rp_paradero` FOREIGN KEY (`paradero_id`) REFERENCES `paraderos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_rp_ruta` FOREIGN KEY (`ruta_id`) REFERENCES `rutas` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `ruta_trazado`
--
ALTER TABLE `ruta_trazado`
  ADD CONSTRAINT `fk_rt_ruta` FOREIGN KEY (`ruta_id`) REFERENCES `rutas` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `tarifas`
--
ALTER TABLE `tarifas`
  ADD CONSTRAINT `fk_tarifa_ruta` FOREIGN KEY (`ruta_id`) REFERENCES `rutas` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `tipos_servicio`
--
ALTER TABLE `tipos_servicio`
  ADD CONSTRAINT `fk_ts_categoria` FOREIGN KEY (`categoria_id`) REFERENCES `categorias_ruta` (`id`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `turnos`
--
ALTER TABLE `turnos`
  ADD CONSTRAINT `fk_turno_bus` FOREIGN KEY (`bus_id`) REFERENCES `buses` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_turno_conductor` FOREIGN KEY (`conductor_id`) REFERENCES `conductores` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_turno_ruta` FOREIGN KEY (`ruta_id`) REFERENCES `rutas` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
