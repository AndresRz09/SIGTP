<?php
declare(strict_types=1);
/**
 * SIGMU – Información Urbana
 * Filtra las rutas del municipio donde está el usuario (municipales, intermunicipales y otros),
 * muestra los buses disponibles cercanos y el detalle: ruta, costo, bus, chofer, pasajeros,
 * horarios y calificación.
 *
 * IMPORTANTE: esta página NO contiene datos de ejemplo. Todo se lee de la base de datos
 * (ejecutar sigmu_db.sql y luego sigmu_urbana.sql). Mientras las tablas estén vacías,
 * se muestran espacios vacíos listos para recibir la información.
 */
session_start();
date_default_timezone_set('America/Bogota');
require_once __DIR__ . '/conexion.php';

if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(16));
}
$csrf = $_SESSION['csrf'];

function json_out(array $d, int $code = 200)
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR);
    exit;
}

function dia_tipo(): string
{
    $n = (int)date('N');
    return $n === 7 ? 'DOM' : ($n === 6 ? 'SAB' : 'LV');
}

function num_o_null($v): ?float
{
    return ($v === null || $v === '') ? null : (float)$v;
}

/** Buses (turnos de hoy) disponibles en una ruta, con última posición, conductor (solo datos públicos) y calificaciones. */
function buses_ruta(PDO $pdo, int $rutaId, ?float $lat, ?float $lng): array
{
    $sql = "SELECT t.id AS turno_id, t.estado AS turno_estado, t.hora_salida, t.hora_llegada_estimada, t.pasajeros_actuales,
                   b.id AS bus_id, b.placa, b.numero_interno, b.marca, b.modelo, b.anio,
                   b.capacidad_sentados, b.capacidad_de_pie, b.accesible, b.aire_acondicionado, b.estado AS bus_estado,
                   d.id AS conductor_id, d.nombres, d.apellidos, d.foto_url, d.anios_experiencia,
                   pb.latitud, pb.longitud, pb.velocidad_kmh, pb.registrado_en,
                   (SELECT AVG(c.puntaje) FROM calificaciones c WHERE c.bus_id = b.id) AS cal_bus,
                   (SELECT COUNT(*)       FROM calificaciones c WHERE c.bus_id = b.id) AS n_cal_bus,
                   (SELECT AVG(c.puntaje) FROM calificaciones c WHERE c.conductor_id = d.id) AS cal_conductor,
                   (SELECT COUNT(*)       FROM calificaciones c WHERE c.conductor_id = d.id) AS n_cal_conductor
            FROM turnos t
            JOIN buses b ON b.id = t.bus_id
            LEFT JOIN conductores d ON d.id = t.conductor_id
            LEFT JOIN posiciones_bus pb ON pb.id = (
                SELECT p2.id FROM posiciones_bus p2 WHERE p2.bus_id = b.id ORDER BY p2.registrado_en DESC LIMIT 1
            )
            WHERE t.ruta_id = :r AND t.fecha = :hoy
              AND t.estado IN ('programado','en_curso')
              AND b.estado IN ('disponible','en_servicio')
            ORDER BY t.hora_salida";
    $st = $pdo->prepare($sql);
    $st->execute([':r' => $rutaId, ':hoy' => date('Y-m-d')]);
    $out = [];
    $ahora = time();
    foreach ($st->fetchAll() as $r) {
        $pos = $r['latitud'] !== null && $r['longitud'] !== null;
        $edad = ($pos && $r['registrado_en']) ? $ahora - strtotime((string)$r['registrado_en']) : null;
        $envivo = $pos && $edad !== null && $edad <= 300; // señal de los últimos 5 min
        $cap = (int)$r['capacidad_sentados'] + (int)$r['capacidad_de_pie'];
        $dist = null;
        if ($pos && $lat !== null && $lng !== null) {
            $dist = haversine_m($lat, $lng, (float)$r['latitud'], (float)$r['longitud']);
        }
        $out[] = [
            'turno_id'       => (int)$r['turno_id'],
            'turno_estado'   => $r['turno_estado'],
            'hora_salida'    => $r['hora_salida'] ? substr((string)$r['hora_salida'], 0, 5) : null,
            'hora_llegada'   => $r['hora_llegada_estimada'] ? substr((string)$r['hora_llegada_estimada'], 0, 5) : null,
            'pasajeros'      => $r['pasajeros_actuales'] !== null ? (int)$r['pasajeros_actuales'] : null,
            'capacidad'      => $cap > 0 ? $cap : null,
            'bus' => [
                'id' => (int)$r['bus_id'], 'placa' => $r['placa'], 'numero_interno' => $r['numero_interno'],
                'marca' => $r['marca'], 'modelo' => $r['modelo'], 'anio' => $r['anio'],
                'cap_sentados' => $r['capacidad_sentados'], 'cap_de_pie' => $r['capacidad_de_pie'],
                'accesible' => $r['accesible'] === null ? null : (int)$r['accesible'],
                'aire' => $r['aire_acondicionado'] === null ? null : (int)$r['aire_acondicionado'],
                'estado' => $r['bus_estado'],
                'calificacion' => num_o_null($r['cal_bus']), 'n_cal' => (int)$r['n_cal_bus'],
            ],
            // Solo datos públicos del conductor (nunca documento ni teléfono)
            'conductor' => $r['conductor_id'] ? [
                'id' => (int)$r['conductor_id'], 'nombres' => $r['nombres'], 'apellidos' => $r['apellidos'],
                'foto_url' => $r['foto_url'], 'anios_experiencia' => $r['anios_experiencia'],
                'calificacion' => num_o_null($r['cal_conductor']), 'n_cal' => (int)$r['n_cal_conductor'],
            ] : null,
            'posicion' => $pos ? [
                'lat' => (float)$r['latitud'], 'lng' => (float)$r['longitud'],
                'velocidad' => num_o_null($r['velocidad_kmh']), 'hace_seg' => $edad, 'en_vivo' => $envivo,
            ] : null,
            'distancia_m' => $dist,
        ];
    }
    // Cercanos primero (con señal), luego por hora de salida
    usort($out, static function ($a, $b) {
        $da = $a['posicion']['en_vivo'] ?? false ? ($a['distancia_m'] ?? INF) : INF;
        $db = $b['posicion']['en_vivo'] ?? false ? ($b['distancia_m'] ?? INF) : INF;
        return $da <=> $db ?: strcmp((string)$a['hora_salida'], (string)$b['hora_salida']);
    });
    return $out;
}

/* ====================== API (JSON) ====================== */
$api = $_GET['api'] ?? null;
if ($_SERVER['REQUEST_METHOD'] === 'GET' && is_string($api)) {
    $pdo = db();
    if (!$pdo) {
        json_out(['ok' => false, 'error' => 'Base de datos no disponible'], 503);
    }
    try {
        switch ($api) {
            /* ---- Resolver el municipio de la BD a partir del nombre detectado ---- */
            case 'municipio':
                $nombre = (string)($_GET['nombre'] ?? '');
                $found = null;
                if ($nombre !== '') {
                    $objetivo = norm($nombre);
                    foreach ($pdo->query('SELECT id, nombre, latitud, longitud FROM municipios')->fetchAll() as $m) {
                        if (norm($m['nombre']) === $objetivo) {
                            $found = ['id' => (int)$m['id'], 'nombre' => $m['nombre'],
                                      'lat' => (float)$m['latitud'], 'lng' => (float)$m['longitud']];
                            break;
                        }
                    }
                }
                json_out(['ok' => true, 'municipio' => $found]);

            /* ---- Rutas del municipio agrupadas por categoría ---- */
            case 'rutas':
                $mid = (int)($_GET['municipio_id'] ?? 0);
                $st = $pdo->prepare(
                    "SELECT r.id, r.codigo, r.nombre, r.origen, r.destino, r.frecuencia_min,
                            COALESCE(c.codigo, 'otros') AS categoria,
                            ts.nombre AS tipo_servicio, e.nombre AS empresa
                     FROM rutas r
                     LEFT JOIN categorias_ruta c ON c.id = r.categoria_id
                     LEFT JOIN tipos_servicio ts ON ts.id = r.tipo_servicio_id
                     LEFT JOIN empresas_transporte e ON e.id = r.empresa_id
                     WHERE r.estado = 'activa'
                       AND EXISTS (SELECT 1 FROM ruta_municipio rm WHERE rm.ruta_id = r.id AND rm.municipio_id = :m)
                     ORDER BY COALESCE(c.orden, 99), r.codigo"
                );
                $st->execute([':m' => $mid]);
                json_out(['ok' => true, 'rutas' => $st->fetchAll()]);

            /* ---- Detalle completo de una ruta ---- */
            case 'ruta':
                $id = (int)($_GET['id'] ?? 0);
                $st = $pdo->prepare(
                    "SELECT r.id, r.codigo, r.nombre, r.origen, r.destino, r.descripcion, r.estado,
                            r.hora_inicio, r.hora_fin, r.frecuencia_min,
                            COALESCE(c.codigo, 'otros') AS categoria, c.nombre AS categoria_nombre,
                            ts.nombre AS tipo_servicio,
                            e.nombre AS empresa, e.telefono AS empresa_telefono
                     FROM rutas r
                     LEFT JOIN categorias_ruta c ON c.id = r.categoria_id
                     LEFT JOIN tipos_servicio ts ON ts.id = r.tipo_servicio_id
                     LEFT JOIN empresas_transporte e ON e.id = r.empresa_id
                     WHERE r.id = :id"
                );
                $st->execute([':id' => $id]);
                $ruta = $st->fetch();
                if (!$ruta) {
                    json_out(['ok' => false, 'error' => 'Ruta no encontrada'], 404);
                }
                $ruta['hora_inicio'] = $ruta['hora_inicio'] ? substr((string)$ruta['hora_inicio'], 0, 5) : null;
                $ruta['hora_fin']    = $ruta['hora_fin'] ? substr((string)$ruta['hora_fin'], 0, 5) : null;

                $q = $pdo->prepare(
                    "SELECT t.concepto, t.valor_cop, t.vigente_desde, t.vigente_hasta
                     FROM tarifas t
                     WHERE t.ruta_id = :id AND t.vigente_desde <= :hoy
                       AND (t.vigente_hasta IS NULL OR t.vigente_hasta >= :hoy2)
                     ORDER BY t.concepto"
                );
                $q->execute([':id' => $id, ':hoy' => date('Y-m-d'), ':hoy2' => date('Y-m-d')]);
                $tarifas = $q->fetchAll();

                $q = $pdo->prepare(
                    "SELECT p.id, p.nombre, p.direccion, p.latitud AS lat, p.longitud AS lng, rp.orden
                     FROM ruta_paradero rp JOIN paraderos p ON p.id = rp.paradero_id
                     WHERE rp.ruta_id = :id ORDER BY rp.orden"
                );
                $q->execute([':id' => $id]);
                $paradas = $q->fetchAll();

                $q = $pdo->prepare('SELECT latitud AS lat, longitud AS lng FROM ruta_trazado WHERE ruta_id = :id ORDER BY orden');
                $q->execute([':id' => $id]);
                $trazado = $q->fetchAll();

                $q = $pdo->prepare(
                    "SELECT TIME_FORMAT(h.hora_salida, '%H:%i') AS hora, p.nombre AS paradero
                     FROM horarios h JOIN paraderos p ON p.id = h.paradero_id
                     WHERE h.ruta_id = :id AND h.dia_tipo = :t
                     ORDER BY h.hora_salida"
                );
                $q->execute([':id' => $id, ':t' => dia_tipo()]);
                $horarios = $q->fetchAll();

                $q = $pdo->prepare('SELECT AVG(puntaje) AS prom, COUNT(*) AS n FROM calificaciones WHERE ruta_id = :id');
                $q->execute([':id' => $id]);
                $agg = $q->fetch();
                $q = $pdo->prepare(
                    "SELECT m.nombre FROM ruta_municipio rm JOIN municipios m ON m.id = rm.municipio_id
                     WHERE rm.ruta_id = :id ORDER BY rm.orden"
                );
                $q->execute([':id' => $id]);

                json_out(['ok' => true, 'ruta' => $ruta, 'tarifas' => $tarifas, 'paradas' => $paradas,
                          'trazado' => $trazado, 'horarios' => $horarios, 'dia_tipo' => dia_tipo(),
                          'municipios' => array_column($q->fetchAll(), 'nombre'),
                          'calificacion' => ['promedio' => num_o_null($agg['prom']), 'total' => (int)$agg['n']]]);

            /* ---- Buses disponibles (se refresca cada pocos segundos) ---- */
            case 'buses':
                $rid = (int)($_GET['ruta_id'] ?? 0);
                $lat = isset($_GET['lat']) && is_numeric($_GET['lat']) ? (float)$_GET['lat'] : null;
                $lng = isset($_GET['lng']) && is_numeric($_GET['lng']) ? (float)$_GET['lng'] : null;
                json_out(['ok' => true, 'buses' => buses_ruta($pdo, $rid, $lat, $lng), 'ts' => time()]);

            /* ---- Comentarios recientes de una ruta ---- */
            case 'comentarios':
                $rid = (int)($_GET['ruta_id'] ?? 0);
                $q = $pdo->prepare(
                    "SELECT puntaje, comentario, DATE_FORMAT(creado_en, '%Y-%m-%d') AS fecha
                     FROM calificaciones WHERE ruta_id = :id AND comentario IS NOT NULL AND comentario <> ''
                     ORDER BY creado_en DESC LIMIT 5"
                );
                $q->execute([':id' => $rid]);
                json_out(['ok' => true, 'comentarios' => $q->fetchAll()]);

            default:
                json_out(['ok' => false, 'error' => 'Acción no válida'], 404);
        }
    } catch (Throwable $ex) {
        json_out(['ok' => false, 'error' => 'No se pudieron leer los datos.',
                  'ayuda' => 'Verifica que importaste sigmu_db.sql y luego sigmu_urbana.sql en phpMyAdmin.'], 500);
    }
}

/* ====================== API (POST): calificar ====================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && str_contains($_SERVER['CONTENT_TYPE'] ?? '', 'application/json')) {
    $in = json_decode(file_get_contents('php://input') ?: '', true);
    $in = is_array($in) ? $in : [];
    if (!hash_equals($_SESSION['csrf'], (string)($in['csrf'] ?? ''))) {
        json_out(['ok' => false, 'error' => 'Token inválido'], 403);
    }
    if (($in['accion'] ?? '') !== 'calificar') {
        json_out(['ok' => false, 'error' => 'Acción no válida'], 400);
    }
    $ruta = (int)($in['ruta_id'] ?? 0);
    $punt = (int)($in['puntaje'] ?? 0);
    $bus  = (int)($in['bus_id'] ?? 0) ?: null;
    $cond = (int)($in['conductor_id'] ?? 0) ?: null;
    $com  = trim(mb_substr((string)($in['comentario'] ?? ''), 0, 500));
    if ($ruta <= 0 || $punt < 1 || $punt > 5) {
        json_out(['ok' => false, 'error' => 'Datos de calificación inválidos'], 422);
    }
    $pdo = db();
    if (!$pdo) {
        json_out(['ok' => false, 'error' => 'Base de datos no disponible'], 503);
    }
    try {
        $sesion = hash('sha256', session_id());
        // Límite: una calificación por sesión y ruta cada 24 horas
        $q = $pdo->prepare(
            'SELECT COUNT(*) FROM calificaciones WHERE sesion_hash = :s AND ruta_id = :r AND creado_en >= (NOW() - INTERVAL 1 DAY)'
        );
        $q->execute([':s' => $sesion, ':r' => $ruta]);
        if ((int)$q->fetchColumn() > 0) {
            json_out(['ok' => false, 'error' => 'Ya calificaste esta ruta hoy. ¡Gracias!'], 429);
        }
        $q = $pdo->prepare('SELECT COUNT(*) FROM rutas WHERE id = :r');
        $q->execute([':r' => $ruta]);
        if ((int)$q->fetchColumn() === 0) {
            json_out(['ok' => false, 'error' => 'Ruta no encontrada'], 404);
        }
        $ins = $pdo->prepare(
            'INSERT INTO calificaciones (ruta_id, bus_id, conductor_id, puntaje, comentario, sesion_hash)
             VALUES (:r, :b, :c, :p, :co, :s)'
        );
        $ins->execute([':r' => $ruta, ':b' => $bus, ':c' => $cond, ':p' => $punt, ':co' => $com !== '' ? $com : null, ':s' => $sesion]);
        json_out(['ok' => true]);
    } catch (Throwable $ex) {
        json_out(['ok' => false, 'error' => 'No se pudo guardar la calificación'], 500);
    }
}

/* ====================== PÁGINA ====================== */
$dbOk = db() !== null;
$municipios = [];
if ($dbOk) {
    try {
        $municipios = db()->query('SELECT id, nombre, latitud AS lat, longitud AS lng FROM municipios ORDER BY nombre')->fetchAll();
        foreach ($municipios as &$m) {
            $m['id'] = (int)$m['id'];
            $m['lat'] = (float)$m['lat'];
            $m['lng'] = (float)$m['lng'];
        }
        unset($m);
    } catch (Throwable $ex) {
        $municipios = [];
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Información Urbana – SIGMU</title>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<style>
:root{
  --bg:#eaf4fb; --bg2:#f6fbff; --ink:#27425a; --ink2:#5b7a93;
  --blue:#59b2e6; --blue-d:#3b8fc4; --mint:#7fdcc4; --mint-d:#4cb99f;
  --sun:#ffd98a; --sun-d:#e9b84f; --coral:#ff9f8a; --lav:#bfb0f5;
  --card:#ffffffd9; --radius:22px;
  --shadow:0 2px 0 #fff inset, 0 18px 30px -12px rgba(59,143,196,.35), 0 6px 10px -4px rgba(39,66,90,.12);
}
*{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{
  font-family:"Segoe UI",system-ui,-apple-system,Roboto,Arial,sans-serif;color:var(--ink);min-height:100vh;overflow-x:hidden;
  background:
    radial-gradient(900px 500px at 10% -10%, #cdeafc 0, transparent 60%),
    radial-gradient(800px 500px at 100% 0%, #dcf7ee 0, transparent 55%),
    radial-gradient(700px 500px at 50% 110%, #fdf1d3 0, transparent 60%),
    var(--bg);
}
.blob{position:fixed;z-index:0;border-radius:50%;opacity:.5;animation:float 12s ease-in-out infinite;pointer-events:none}
.blob.b1{width:170px;height:170px;left:-50px;top:35%;background:radial-gradient(circle at 30% 30%,#fff,var(--lav))}
.blob.b2{width:120px;height:120px;right:-30px;top:60%;background:radial-gradient(circle at 30% 30%,#fff,var(--sun));animation-delay:-4s}
@keyframes float{0%,100%{transform:translateY(0) rotate(0)}50%{transform:translateY(-26px) rotate(12deg)}}

/* Navegación */
header.nav{position:sticky;top:0;z-index:1000;display:flex;align-items:center;gap:18px;flex-wrap:wrap;padding:12px clamp(14px,4vw,40px);
  background:linear-gradient(180deg,#ffffffee,#f1f9ffee);backdrop-filter:blur(10px);box-shadow:0 10px 25px -14px rgba(59,143,196,.5);border-bottom:1px solid #fff}
.logo{display:flex;align-items:center;gap:10px;font-weight:800;font-size:1.35rem;letter-spacing:.04em;color:var(--blue-d);text-decoration:none}
.logo .cube{width:40px;height:40px;border-radius:12px;display:grid;place-items:center;font-size:1.3rem;background:linear-gradient(135deg,var(--blue),var(--mint));color:#fff;box-shadow:0 5px 0 var(--blue-d),0 12px 18px -6px rgba(59,143,196,.6);transform:rotate(-6deg)}
nav.menu{display:flex;gap:8px;flex-wrap:wrap;margin-left:auto;align-items:center}
.btn,.menu a{display:inline-flex;align-items:center;gap:8px;text-decoration:none;cursor:pointer;border:0;font:inherit;font-weight:600;color:var(--ink);padding:9px 18px;border-radius:14px;background:#fff;
  box-shadow:0 4px 0 #cfe5f4,0 10px 16px -8px rgba(59,143,196,.45);transition:transform .15s,box-shadow .15s,background .2s}
.btn:hover,.menu a:hover{transform:translateY(-2px);background:#f4fbff}
.btn:active,.menu a:active{transform:translateY(3px);box-shadow:0 1px 0 #cfe5f4}
.menu a.primary,.btn.primary{background:linear-gradient(135deg,var(--blue),#7cc8f0);color:#fff;box-shadow:0 4px 0 var(--blue-d),0 12px 18px -8px rgba(59,143,196,.7)}
.btn.mint{background:linear-gradient(135deg,var(--mint),#a6ebd8);color:#14513f;box-shadow:0 4px 0 var(--mint-d),0 12px 18px -8px rgba(76,185,159,.7)}
.btn.sm{padding:6px 12px;font-size:.85rem;border-radius:12px}

/* Estructura */
.wrap{position:relative;z-index:1;max-width:1380px;margin:22px auto;padding:0 clamp(14px,3vw,30px);display:flex;flex-direction:column;gap:22px}
.card{background:var(--card);border-radius:var(--radius);padding:20px;box-shadow:var(--shadow);border:1px solid #fff;backdrop-filter:blur(6px)}
.card h2,.card h3{margin-bottom:10px}
.badge{display:inline-block;font-size:.76rem;font-weight:700;padding:3px 10px;border-radius:99px;background:#e1f5ee;color:#1d7a62}
.badge.blue{background:#dff1fc;color:#2a77a6}.badge.warn{background:#fff1d6;color:#8a6410}.badge.bad{background:#ffe3dc;color:#a8432d}.badge.lav{background:#ece6ff;color:#5a45b0}
.demo{background:#fff1d6;color:#8a6410;padding:8px 16px;text-align:center;font-weight:600;font-size:.88rem;position:relative;z-index:2}

/* Barra de ubicación + buscador */
.topbar{display:flex;gap:18px;align-items:center;flex-wrap:wrap}
.ubic{flex:1;min-width:260px;display:flex;align-items:center;gap:14px}
.ubic .ico{width:50px;height:50px;border-radius:16px;display:grid;place-items:center;font-size:1.5rem;background:linear-gradient(135deg,var(--sun),#ffeab9);box-shadow:0 4px 0 var(--sun-d)}
.ubic small{display:block;color:var(--ink2);font-weight:600;text-transform:uppercase;letter-spacing:.06em;font-size:.72rem}
.ubic b{font-size:1.15rem}
.ubic .sub{color:var(--ink2);font-size:.88rem}
.search{display:flex;align-items:center;gap:8px;background:#fff;border-radius:16px;padding:6px 8px 6px 16px;box-shadow:0 4px 0 #d6e9f6,inset 0 2px 4px rgba(59,143,196,.12);min-width:260px;flex:0 1 380px}
.search input{border:0;outline:0;background:transparent;font:inherit;color:var(--ink);flex:1;min-width:0;padding:8px 0}
.search button{border:0;cursor:pointer;width:38px;height:38px;border-radius:12px;font-size:1rem;background:linear-gradient(135deg,var(--blue),#7cc8f0);color:#fff;box-shadow:0 3px 0 var(--blue-d)}
.sel{font:inherit;color:var(--ink);padding:9px 12px;border-radius:12px;border:0;background:#fff;box-shadow:0 3px 0 #d6e9f6;max-width:230px}
.aviso{margin-top:12px;padding:10px 14px;border-radius:14px;background:#eef7fd;font-weight:600;font-size:.92rem}
.aviso.ok{background:#e1f7ef;color:#1d7a62}.aviso.err{background:#ffe8e1;color:#a8432d}

/* Cuerpo: lista + mapa + detalle */
.cols{display:grid;grid-template-columns:350px minmax(0,1fr);gap:22px;align-items:start}
.lista{position:sticky;top:84px;max-height:calc(100vh - 104px);overflow:auto;display:flex;flex-direction:column;gap:14px;padding-right:4px}
.grupo{background:var(--card);border-radius:20px;box-shadow:var(--shadow);border:1px solid #fff;overflow:hidden}
.grupo>button.gh{width:100%;display:flex;align-items:center;gap:10px;padding:14px 16px;border:0;cursor:pointer;font:inherit;font-weight:800;font-size:1.02rem;color:var(--ink);text-align:left}
.grupo.municipal>button.gh{background:linear-gradient(135deg,#d6efff,#bfe5fb)}
.grupo.intermunicipal>button.gh{background:linear-gradient(135deg,#d9f9ec,#bdeedc)}
.grupo.otros>button.gh{background:linear-gradient(135deg,#ece6ff,#ddd2fb)}
.gh .n{margin-left:auto;background:#fff;border-radius:99px;padding:2px 10px;font-size:.8rem;box-shadow:0 2px 0 rgba(0,0,0,.08)}
.gh .chev{transition:transform .25s}
.grupo.cerrado .chev{transform:rotate(-90deg)}
.grupo.cerrado .items{display:none}
.items{display:flex;flex-direction:column;gap:8px;padding:12px}
.item{display:flex;align-items:center;gap:10px;width:100%;text-align:left;font:inherit;color:var(--ink);cursor:pointer;border:0;padding:11px 12px;border-radius:14px;background:#f3faff;box-shadow:0 3px 0 #d6e9f6;transition:.18s}
.item:hover{transform:translateX(5px);background:#e6f5ff}
.item.sel{background:linear-gradient(135deg,var(--blue),#8bd0f4);color:#fff;box-shadow:0 3px 0 var(--blue-d)}
.item .cod{font-weight:800;min-width:54px}
.item .t{flex:1;min-width:0}
.item .t b{display:block;font-size:.93rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.item .t small{display:block;opacity:.8;font-size:.78rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.item .go{font-weight:800;font-size:1.2rem}
.vacio-box{border:2px dashed #bcd9ec;border-radius:16px;padding:16px;text-align:center;color:var(--ink2);font-size:.9rem;line-height:1.5;background:#f8fcff}
.vacio{color:#9bb4c6;font-style:italic;font-weight:500}

.centro{display:flex;flex-direction:column;gap:22px;min-width:0}
#map{height:430px;border-radius:20px;box-shadow:0 0 0 6px #fff,0 18px 30px -14px rgba(59,143,196,.5);z-index:1}
.pin{font-size:26px;filter:drop-shadow(0 6px 3px rgba(0,0,0,.3));text-align:center;line-height:1}
.pin.bus{font-size:28px}
.pin.sel{transform:scale(1.35)}
.leyenda{display:flex;gap:14px;flex-wrap:wrap;margin-top:12px;font-size:.85rem;color:var(--ink2);font-weight:600}

/* Detalle con pestañas */
.tabs{display:flex;gap:8px;overflow-x:auto;padding:4px 2px 10px;scrollbar-width:thin}
.tab{flex:0 0 auto;border:0;cursor:pointer;font:inherit;font-weight:700;color:var(--ink);padding:9px 16px;border-radius:14px;background:#fff;box-shadow:0 4px 0 #cfe5f4;transition:.15s}
.tab:hover{transform:translateY(-2px)}
.tab.on{background:linear-gradient(135deg,var(--blue),#7cc8f0);color:#fff;box-shadow:0 4px 0 var(--blue-d)}
.panel{display:none;animation:in .35s ease}
.panel.on{display:block}
@keyframes in{from{opacity:0;transform:translateY(8px) rotateX(6deg)}to{opacity:1;transform:none}}
.kv{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px}
.kv .row{background:linear-gradient(135deg,#f6fbff,#e9f5fd);border-radius:14px;padding:10px 14px;box-shadow:0 3px 0 #d6e9f6}
.kv dt{font-size:.72rem;text-transform:uppercase;letter-spacing:.06em;color:var(--ink2);font-weight:700}
.kv dd{font-weight:700;word-break:break-word}
.titulo-ruta{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:14px}
.titulo-ruta h3{margin:0;font-size:1.35rem}
table{width:100%;border-collapse:separate;border-spacing:0 7px}
th{font-size:.76rem;text-transform:uppercase;letter-spacing:.06em;color:var(--ink2);text-align:left;padding:0 12px}
td{padding:10px 12px;background:#f3faff;font-size:.93rem}
td:first-child{border-radius:12px 0 0 12px}td:last-child{border-radius:0 12px 12px 0}
tr.prox td{background:#dff7ee;font-weight:800}
.bus-card{display:flex;gap:14px;align-items:center;flex-wrap:wrap;padding:14px;border-radius:18px;background:#f3faff;box-shadow:0 3px 0 #d6e9f6;cursor:pointer;transition:.2s;margin-bottom:10px;border:2px solid transparent}
.bus-card:hover{transform:translateY(-3px)}
.bus-card.sel{border-color:var(--blue);background:#e6f5ff}
.bus-card .b-ico{font-size:2rem}
.bus-card .info{flex:1;min-width:160px}
.bus-card .dist{font-weight:800;color:var(--blue-d);white-space:nowrap}
.barra{height:12px;border-radius:99px;background:#dbe9f3;overflow:hidden;box-shadow:inset 0 2px 3px rgba(0,0,0,.1)}
.barra i{display:block;height:100%;border-radius:99px;background:linear-gradient(90deg,var(--mint),var(--sun),var(--coral))}
.avatar{width:84px;height:84px;border-radius:24px;object-fit:cover;display:grid;place-items:center;font-size:2rem;font-weight:800;color:#fff;background:linear-gradient(135deg,var(--blue),var(--mint));box-shadow:0 5px 0 var(--blue-d),0 14px 18px -8px rgba(59,143,196,.6);transform:rotate(-3deg)}
.chofer{display:flex;gap:18px;align-items:center;flex-wrap:wrap;margin-bottom:14px}
.stars{color:#f4b73e;letter-spacing:2px;font-size:1.2rem}
.score{font-size:2.4rem;font-weight:800;color:var(--blue-d);line-height:1}
.coment{background:#f6fbff;border-radius:14px;padding:10px 14px;margin-bottom:8px;box-shadow:0 3px 0 #e1eef7}
.coment small{color:var(--ink2)}
.rate{margin-top:16px;padding:16px;border-radius:18px;background:linear-gradient(135deg,#fff8e4,#fff1cc);box-shadow:0 4px 0 #f3dfa5}
.rate .pick{display:flex;gap:4px;margin:8px 0}
.rate .pick button{border:0;background:transparent;cursor:pointer;font-size:2rem;color:#d7c9a0;transition:.15s}
.rate .pick button.on{color:#f4b73e;transform:scale(1.15)}
.rate textarea,.rate select{width:100%;font:inherit;color:var(--ink);padding:10px 12px;border-radius:12px;border:0;box-shadow:inset 0 2px 4px rgba(0,0,0,.1);background:#fff;margin-bottom:8px}
.nota{font-size:.82rem;color:var(--ink2);margin-top:10px}
.placeholder-hero{text-align:center;padding:34px 16px}
.placeholder-hero .big{font-size:3.2rem;display:block;margin-bottom:8px;animation:float 6s ease-in-out infinite}
footer{position:relative;z-index:1;text-align:center;color:var(--ink2);padding:24px 14px 40px;font-size:.9rem}

@media (max-width:1000px){.cols{grid-template-columns:1fr}.lista{position:static;max-height:none}nav.menu{margin-left:0}}
@media (max-width:560px){#map{height:340px}}
@media (prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}
</style>
</head>
<body>
<div class="blob b1"></div><div class="blob b2"></div>

<?php if (!$dbOk): ?>
<div class="demo">⚠️ No se pudo conectar con la base de datos <b>sigmu_db</b>. Importa <b>sigmu_db.sql</b> y <b>sigmu_urbana.sql</b> y revisa <b>conexion.php</b>.</div>
<?php endif; ?>

<!-- ============ BARRA DE NAVEGACIÓN ============ -->
<header class="nav">
  <a class="logo" href="index.php"><span class="cube">🚌</span> SIGMU</a>
  <nav class="menu" aria-label="Navegación principal">
    <a href="index.php">🏠 Inicio</a>
    <a href="Informacion_Urbana.php" class="primary">🏙️ Información Urbana</a>
    <a href="index.php#seguridad">🛡️ Seguridad</a>
    <a href="index.php#pars">🚏 PARS</a>
    <a href="login.php" title="Iniciar sesión">🔐 IS</a>
  </nav>
</header>

<div class="wrap">
  <!-- ============ UBICACIÓN ACTUAL + BUSCAR ============ -->
  <section class="card">
    <div class="topbar">
      <div class="ubic">
        <div class="ico">📍</div>
        <div>
          <small>Ubicación actual</small>
          <b id="u-muni">Detectando…</b>
          <div class="sub" id="u-sub">Esperando permiso de ubicación</div>
        </div>
      </div>
      <select class="sel" id="selMuni" aria-label="Cambiar municipio">
        <option value="">Cambiar municipio…</option>
        <?php foreach ($municipios as $m): ?>
          <option value="<?= (int)$m['id'] ?>"><?= e($m['nombre']) ?></option>
        <?php endforeach; ?>
      </select>
      <button class="btn mint sm" id="btnReubicar" type="button">📡 Volver a escanear</button>
      <div class="search">
        <input type="search" id="buscar" placeholder="Buscar ruta, destino o empresa…" aria-label="Buscar">
        <button type="button" id="btnBuscar" aria-label="Buscar">🔍</button>
      </div>
    </div>
    <div class="aviso" id="aviso" style="display:none"></div>
  </section>

  <div class="cols">
    <!-- ============ LISTA: MUNICIPALES / INTERMUNICIPALES / OTROS ============ -->
    <aside class="lista" id="lista" aria-label="Rutas del municipio">
      <div class="vacio-box">Cuando se detecte tu municipio, aquí aparecerán sus rutas.</div>
    </aside>

    <div class="centro">
      <!-- ============ VISUALIZACIÓN BUSES ============ -->
      <section class="card">
        <h2>🗺️ Visualización de buses</h2>
        <div id="map"></div>
        <div class="leyenda"><span>📍 Tu ubicación</span><span>🚏 Paradas de la ruta</span><span>🚌 Buses con señal GPS</span></div>
      </section>

      <!-- ============ DETALLE DE LA RUTA ============ -->
      <section class="card" id="detalle">
        <div class="placeholder-hero" id="detalle-vacio">
          <span class="big">🚌</span>
          <h3>Selecciona una ruta de la lista</h3>
          <p style="color:var(--ink2)">Verás la ruta, el costo, los buses disponibles cercanos, la información del bus y del chofer, los pasajeros, los horarios y la calificación.</p>
        </div>
        <div id="detalle-cont" style="display:none">
          <div class="titulo-ruta" id="d-titulo"></div>
          <div class="tabs" role="tablist" id="tabs">
            <button class="tab on" data-t="ruta" type="button">🛣️ Ruta</button>
            <button class="tab" data-t="costo" type="button">💵 Costo</button>
            <button class="tab" data-t="buses" type="button">🚌 Buses</button>
            <button class="tab" data-t="chofer" type="button">🧑‍✈️ Chofer</button>
            <button class="tab" data-t="pasajeros" type="button">👥 Pasajeros</button>
            <button class="tab" data-t="horarios" type="button">🕒 Horarios</button>
            <button class="tab" data-t="calif" type="button">⭐ Calificación</button>
          </div>
          <div class="panel on" id="p-ruta"></div>
          <div class="panel" id="p-costo"></div>
          <div class="panel" id="p-buses"></div>
          <div class="panel" id="p-chofer"></div>
          <div class="panel" id="p-pasajeros"></div>
          <div class="panel" id="p-horarios"></div>
          <div class="panel" id="p-calif"></div>
        </div>
      </section>
    </div>
  </div>
</div>

<footer>SIGMU · Información Urbana · Mapas © colaboradores de OpenStreetMap</footer>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
const MUNICIPIOS = <?= json_encode($municipios, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
const CSRF = <?= json_encode($csrf) ?>;
const $ = (s) => document.querySelector(s);
const esc = (t) => String(t ?? '').replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const SIN = '<span class="vacio">Sin registrar</span>';
const val = (v, suf = '') => (v === null || v === undefined || v === '') ? SIN : esc(v) + suf;
const sino = (v) => v === null || v === undefined ? SIN : (Number(v) ? 'Sí' : 'No');
const fmtDist = (m) => m == null ? '—' : (m < 1000 ? Math.round(m) + ' m' : (m / 1000).toFixed(1) + ' km');
const cop = (n) => new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 }).format(Number(n));
const stars = (v) => { const r = Math.round(v || 0); return '★'.repeat(r) + '☆'.repeat(5 - r); };
const vacioBox = (msg) => `<div class="vacio-box">${msg}</div>`;
const api = (p) => fetch('?' + new URLSearchParams(p)).then((r) => r.json());

const CATS = [
  { k: 'municipal', n: 'Municipales', i: '🏘️' },
  { k: 'intermunicipal', n: 'Intermunicipales', i: '🛣️' },
  { k: 'otros', n: 'Otros', i: '🎒' }
];

const S = { loc: null, muni: null, rutas: [], ruta: null, det: null, buses: [], bus: null, timer: null, abiertos: { municipal: true, intermunicipal: true, otros: true } };

/* ================= MAPA ================= */
const map = L.map('map').setView([4.7110, -74.0721], 11);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>' }).addTo(map);
const capaUser = L.layerGroup().addTo(map), capaRuta = L.layerGroup().addTo(map), capaBuses = L.layerGroup().addTo(map);
const icono = (emoji, cls = '') => L.divIcon({ html: `<div class="pin ${cls}">${emoji}</div>`, className: '', iconSize: [30, 30], iconAnchor: [15, 28], popupAnchor: [0, -26] });

function avisar(msg, tipo = '') {
  const a = $('#aviso');
  if (!msg) { a.style.display = 'none'; return; }
  a.className = 'aviso' + (tipo ? ' ' + tipo : ''); a.textContent = msg; a.style.display = 'block';
}

/* ================= UBICACIÓN ================= */
function ubicacionGuardada() {
  try {
    const g = JSON.parse(localStorage.getItem('sigmu_ubicacion') || 'null');
    if (g && Date.now() - g.ts < 30 * 60 * 1000) return g;
  } catch (_) {}
  return null;
}

async function escanear() {
  if (!('geolocation' in navigator)) { avisar('Tu navegador no soporta geolocalización. Elige tu municipio en la lista.', 'err'); return; }
  avisar('🔎 Buscando tu ubicación…');
  navigator.geolocation.getCurrentPosition(async (pos) => {
    const { latitude: lat, longitude: lng, accuracy } = pos.coords;
    let municipio = '', barrio = '';
    try {
      const r = await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&addressdetails=1&accept-language=es&zoom=16&lat=${lat}&lon=${lng}`);
      const j = await r.json(); const a = j.address || {};
      municipio = a.city || a.town || a.village || a.municipality || a.county || a.state_district || '';
      barrio = a.neighbourhood || a.suburb || a.quarter || a.city_district || '';
    } catch (_) {}
    const loc = { lat, lng, precision: accuracy, municipio, barrio, ts: Date.now() };
    try { localStorage.setItem('sigmu_ubicacion', JSON.stringify(loc)); } catch (_) {}
    aplicarUbicacion(loc);
  }, () => {
    avisar('No pudimos obtener tu ubicación. Elige tu municipio en la lista “Cambiar municipio”.', 'err');
    $('#u-muni').textContent = 'Municipio no definido';
    $('#u-sub').textContent = 'Permiso de ubicación no concedido';
  }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 });
}

async function aplicarUbicacion(loc) {
  S.loc = loc;
  capaUser.clearLayers();
  if (loc.lat != null) {
    L.marker([loc.lat, loc.lng], { icon: icono('📍') }).addTo(capaUser).bindPopup('<b>Estás aquí</b>');
    if (loc.precision) L.circle([loc.lat, loc.lng], { radius: loc.precision, color: '#59b2e6', fillOpacity: .1, weight: 1 }).addTo(capaUser);
    map.setView([loc.lat, loc.lng], 13);
  }
  $('#u-muni').textContent = loc.municipio || 'Municipio no identificado';
  $('#u-sub').textContent = [loc.barrio, loc.lat != null ? `${loc.lat.toFixed(5)}, ${loc.lng.toFixed(5)}` : ''].filter(Boolean).join(' · ') || '—';

  const r = await api({ api: 'municipio', nombre: loc.municipio || '' }).catch(() => null);
  if (r && r.ok && r.municipio) {
    avisar('');
    setMunicipio(r.municipio);
  } else if (r && r.ok) {
    avisar(`“${loc.municipio || 'tu municipio'}” todavía no está registrado en la base de datos. Elige otro municipio en la lista o agrégalo en la tabla municipios.`, 'err');
    S.muni = null; S.rutas = []; renderLista();
  } else {
    avisar((r && r.ayuda) || 'No se pudo consultar la base de datos.', 'err');
  }
}

function setMunicipio(m) {
  S.muni = m;
  $('#selMuni').value = String(m.id);
  if (!S.loc || S.loc.lat == null) map.setView([m.lat, m.lng], 12);
  cargarRutas();
}

/* ================= LISTA DE RUTAS ================= */
async function cargarRutas() {
  limpiarRuta();
  const r = await api({ api: 'rutas', municipio_id: S.muni.id }).catch(() => null);
  if (!r || !r.ok) { avisar((r && r.ayuda) || 'No se pudieron cargar las rutas.', 'err'); return; }
  S.rutas = r.rutas;
  renderLista();
}

function renderLista() {
  const box = $('#lista');
  const q = $('#buscar').value.trim().toLowerCase();
  if (!S.muni) { box.innerHTML = vacioBox('Elige un municipio para ver sus rutas.'); return; }
  box.innerHTML = '';
  CATS.forEach((c) => {
    const todas = S.rutas.filter((r) => r.categoria === c.k);
    const lista = todas.filter((r) => !q || [r.codigo, r.nombre, r.origen, r.destino, r.empresa, r.tipo_servicio].join(' ').toLowerCase().includes(q));
    const g = document.createElement('div');
    g.className = `grupo ${c.k}` + (S.abiertos[c.k] ? '' : ' cerrado');
    g.innerHTML = `<button class="gh" type="button"><span>${c.i}</span> ${c.n} <span class="n">${lista.length}</span><span class="chev">▾</span></button><div class="items"></div>`;
    g.querySelector('.gh').addEventListener('click', () => { S.abiertos[c.k] = !S.abiertos[c.k]; g.classList.toggle('cerrado'); });
    const items = g.querySelector('.items');
    if (!lista.length) {
      items.innerHTML = vacioBox(todas.length ? 'Ninguna ruta coincide con la búsqueda.' : `Aún no hay rutas ${c.n.toLowerCase()} registradas para ${esc(S.muni.nombre)}.`);
    }
    lista.forEach((r) => {
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'item' + (S.ruta === r.id ? ' sel' : '');
      b.innerHTML = `<span class="cod">${esc(r.codigo)}</span><span class="t"><b>${esc(r.nombre)}</b><small>${esc([r.origen, r.destino].filter(Boolean).join(' → '))}${r.tipo_servicio ? ' · ' + esc(r.tipo_servicio) : ''}</small></span><span class="go">›</span>`;
      b.addEventListener('click', () => seleccionarRuta(r.id));
      items.appendChild(b);
    });
    box.appendChild(g);
  });
}

/* ================= SELECCIÓN DE RUTA ================= */
function limpiarRuta() {
  clearInterval(S.timer); S.timer = null;
  S.ruta = null; S.det = null; S.buses = []; S.bus = null;
  capaRuta.clearLayers(); capaBuses.clearLayers();
  $('#detalle-vacio').style.display = ''; $('#detalle-cont').style.display = 'none';
}

async function seleccionarRuta(id) {
  clearInterval(S.timer);
  S.ruta = id; S.bus = null; renderLista();
  const [d, b] = await Promise.all([
    api({ api: 'ruta', id }).catch(() => null),
    api({ api: 'buses', ruta_id: id, ...(S.loc && S.loc.lat != null ? { lat: S.loc.lat, lng: S.loc.lng } : {}) }).catch(() => null)
  ]);
  if (!d || !d.ok) { avisar('No se pudo cargar el detalle de la ruta.', 'err'); return; }
  S.det = d; S.buses = (b && b.ok) ? b.buses : [];
  S.bus = S.buses.length ? S.buses[0].turno_id : null;
  const c = await api({ api: 'comentarios', ruta_id: id }).catch(() => null);
  S.det.comentarios = (c && c.ok) ? c.comentarios : [];
  $('#detalle-vacio').style.display = 'none'; $('#detalle-cont').style.display = '';
  dibujarRuta(); renderTodo();
  S.timer = setInterval(refrescarBuses, 15000);
  document.getElementById('detalle').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

async function refrescarBuses() {
  if (!S.ruta) return;
  const b = await api({ api: 'buses', ruta_id: S.ruta, ...(S.loc && S.loc.lat != null ? { lat: S.loc.lat, lng: S.loc.lng } : {}) }).catch(() => null);
  if (!b || !b.ok) return;
  S.buses = b.buses;
  if (!S.buses.some((x) => x.turno_id === S.bus)) S.bus = S.buses.length ? S.buses[0].turno_id : null;
  dibujarBuses(); renderBuses(); renderBus(); renderChofer(); renderPasajeros();
}

/* ================= MAPA: ruta, paradas, buses ================= */
function dibujarRuta() {
  capaRuta.clearLayers();
  const d = S.det; const pts = [];
  const linea = d.trazado.length >= 2 ? d.trazado : (d.paradas.length >= 2 ? d.paradas : []);
  if (linea.length) {
    const ll = linea.map((p) => [Number(p.lat), Number(p.lng)]);
    L.polyline(ll, { color: '#3b8fc4', weight: 5, opacity: .85, dashArray: d.trazado.length >= 2 ? null : '8 8' }).addTo(capaRuta);
    pts.push(...ll);
  }
  d.paradas.forEach((p) => {
    const ll = [Number(p.lat), Number(p.lng)]; pts.push(ll);
    L.marker(ll, { icon: icono('🚏') }).addTo(capaRuta).bindPopup(`<b>${esc(p.nombre)}</b><br>${esc(p.direccion || '')}`);
  });
  dibujarBuses(true);
  if (pts.length) map.fitBounds(L.latLngBounds(pts), { padding: [30, 30] });
}

function dibujarBuses(ajustar = false) {
  capaBuses.clearLayers();
  const pts = [];
  S.buses.forEach((b) => {
    if (!b.posicion || !b.posicion.en_vivo) return;
    const ll = [b.posicion.lat, b.posicion.lng]; pts.push(ll);
    const m = L.marker(ll, { icon: icono('🚌', 'bus' + (b.turno_id === S.bus ? ' sel' : '')) }).addTo(capaBuses)
      .bindPopup(`<b>${esc(b.bus.placa)}</b>${b.bus.numero_interno ? ' · N° ' + esc(b.bus.numero_interno) : ''}<br>${b.distancia_m != null ? 'A ' + fmtDist(b.distancia_m) + ' de ti' : ''}`);
    m.on('click', () => { S.bus = b.turno_id; dibujarBuses(); renderBuses(); renderBus(); renderChofer(); renderPasajeros(); });
  });
  if (ajustar && pts.length && !S.det.paradas.length && !S.det.trazado.length) map.fitBounds(L.latLngBounds(pts), { padding: [40, 40] });
}

/* ================= PANELES DE DETALLE ================= */
const busSel = () => S.buses.find((b) => b.turno_id === S.bus) || null;

function renderTodo() {
  const r = S.det.ruta;
  $('#d-titulo').innerHTML = `<span class="badge blue">${esc(r.codigo)}</span><h3>${esc(r.nombre)}</h3>` +
    `<span class="badge ${r.categoria === 'municipal' ? 'blue' : r.categoria === 'intermunicipal' ? '' : 'lav'}">${esc(r.categoria_nombre || r.categoria)}</span>` +
    (r.tipo_servicio ? `<span class="badge lav">${esc(r.tipo_servicio)}</span>` : '');
  renderRuta(); renderCosto(); renderBuses(); renderBus(); renderChofer(); renderPasajeros(); renderHorarios(); renderCalif();
}

function renderRuta() {
  const { ruta: r, paradas, municipios } = S.det;
  $('#p-ruta').innerHTML = `
    <dl class="kv">
      <div class="row"><dt>Origen</dt><dd>${val(r.origen)}</dd></div>
      <div class="row"><dt>Destino</dt><dd>${val(r.destino)}</dd></div>
      <div class="row"><dt>Empresa</dt><dd>${val(r.empresa)}</dd></div>
      <div class="row"><dt>Teléfono de la empresa</dt><dd>${val(r.empresa_telefono)}</dd></div>
      <div class="row"><dt>Primer servicio</dt><dd>${val(r.hora_inicio)}</dd></div>
      <div class="row"><dt>Último servicio</dt><dd>${val(r.hora_fin)}</dd></div>
      <div class="row"><dt>Frecuencia</dt><dd>${val(r.frecuencia_min, ' min')}</dd></div>
      <div class="row"><dt>Municipios que recorre</dt><dd>${municipios.length ? esc(municipios.join(' · ')) : SIN}</dd></div>
    </dl>
    <h4 style="margin:16px 0 8px">Descripción</h4><p>${val(r.descripcion)}</p>
    <h4 style="margin:16px 0 8px">Paradas (en orden)</h4>
    ${paradas.length ? `<table><thead><tr><th>#</th><th>Parada</th><th>Dirección</th></tr></thead><tbody>${paradas.map((p) => `<tr><td>${esc(p.orden)}</td><td><b>${esc(p.nombre)}</b></td><td>${val(p.direccion)}</td></tr>`).join('')}</tbody></table>` : vacioBox('Esta ruta aún no tiene paradas registradas (tabla <b>ruta_paradero</b>).')}`;
}

function renderCosto() {
  const t = S.det.tarifas;
  $('#p-costo').innerHTML = t.length
    ? `<table><thead><tr><th>Concepto</th><th>Valor</th><th>Vigente desde</th><th>Hasta</th></tr></thead><tbody>${t.map((x) => `<tr><td>${esc(x.concepto)}</td><td><b>${cop(x.valor_cop)}</b></td><td>${esc(x.vigente_desde)}</td><td>${x.vigente_hasta ? esc(x.vigente_hasta) : SIN}</td></tr>`).join('')}</tbody></table>`
    : vacioBox('Aún no hay tarifas vigentes registradas para esta ruta (tabla <b>tarifas</b>).');
}

function renderBuses() {
  const box = $('#p-buses');
  if (!S.buses.length) {
    box.innerHTML = vacioBox('No hay buses disponibles para esta ruta en este momento. Aparecerán cuando se registren turnos de hoy (tabla <b>turnos</b>) y la app del conductor envíe su posición.');
    return;
  }
  box.innerHTML = '<p style="color:var(--ink2);margin-bottom:10px">Ordenados del más cercano al más lejano. Se actualizan cada 15 segundos.</p>';
  S.buses.forEach((b) => {
    const live = b.posicion && b.posicion.en_vivo;
    const el = document.createElement('div');
    el.className = 'bus-card' + (b.turno_id === S.bus ? ' sel' : '');
    el.innerHTML = `<span class="b-ico">🚌</span>
      <div class="info"><b>${esc(b.bus.placa)}</b>${b.bus.numero_interno ? ' · N° ' + esc(b.bus.numero_interno) : ''}<br>
        <small>Salida: ${val(b.hora_salida)} · ${b.turno_estado === 'en_curso' ? 'En curso' : 'Programado'}</small><br>
        <span class="badge ${live ? '' : 'warn'}">${live ? '● Señal GPS en vivo' : 'Sin señal GPS reciente'}</span></div>
      <div class="dist">${live ? fmtDist(b.distancia_m) : '—'}</div>`;
    el.addEventListener('click', () => { S.bus = b.turno_id; dibujarBuses(); renderBuses(); renderBus(); renderChofer(); renderPasajeros();
      if (live) map.flyTo([b.posicion.lat, b.posicion.lng], 16); });
    box.appendChild(el);
  });
}

function renderBus() {
  const b = busSel(); const box = $('#p-buses');
  const prev = box.querySelector('.det-bus'); if (prev) prev.remove();
  if (!b) return;
  const x = b.bus, p = b.posicion;
  const d = document.createElement('div'); d.className = 'det-bus';
  d.innerHTML = `<h4 style="margin:16px 0 8px">Información del bus seleccionado</h4>
    <dl class="kv">
      <div class="row"><dt>Placa</dt><dd>${val(x.placa)}</dd></div>
      <div class="row"><dt>Número interno</dt><dd>${val(x.numero_interno)}</dd></div>
      <div class="row"><dt>Marca / modelo</dt><dd>${val([x.marca, x.modelo].filter(Boolean).join(' ') || null)}</dd></div>
      <div class="row"><dt>Año</dt><dd>${val(x.anio)}</dd></div>
      <div class="row"><dt>Puestos sentados</dt><dd>${val(x.cap_sentados)}</dd></div>
      <div class="row"><dt>Puestos de pie</dt><dd>${val(x.cap_de_pie)}</dd></div>
      <div class="row"><dt>Accesible (movilidad reducida)</dt><dd>${sino(x.accesible)}</dd></div>
      <div class="row"><dt>Aire acondicionado</dt><dd>${sino(x.aire)}</dd></div>
      <div class="row"><dt>Velocidad actual</dt><dd>${p && p.velocidad != null ? esc(Math.round(p.velocidad)) + ' km/h' : SIN}</dd></div>
      <div class="row"><dt>Última señal</dt><dd>${p && p.hace_seg != null ? 'hace ' + (p.hace_seg < 60 ? p.hace_seg + ' s' : Math.round(p.hace_seg / 60) + ' min') : SIN}</dd></div>
      <div class="row"><dt>Calificación del bus</dt><dd>${x.calificacion != null ? `<span class="stars">${stars(x.calificacion)}</span> ${x.calificacion.toFixed(1)} (${x.n_cal})` : SIN}</dd></div>
    </dl>`;
  box.appendChild(d);
}

function renderChofer() {
  const b = busSel(); const box = $('#p-chofer');
  if (!b) { box.innerHTML = vacioBox('Selecciona un bus disponible en la pestaña <b>Buses</b> para ver a su chofer.'); return; }
  const c = b.conductor;
  if (!c) { box.innerHTML = vacioBox('Este turno todavía no tiene un chofer asignado (tabla <b>turnos</b>, campo conductor_id).'); return; }
  const nombre = [c.nombres, c.apellidos].filter(Boolean).join(' ');
  const avatar = c.foto_url ? `<img class="avatar" src="${esc(c.foto_url)}" alt="Foto del chofer">` : `<div class="avatar">${esc((c.nombres || '?').charAt(0).toUpperCase())}</div>`;
  box.innerHTML = `<div class="chofer">${avatar}<div><h3 style="margin:0">${esc(nombre)}</h3>
    <div>${c.calificacion != null ? `<span class="stars">${stars(c.calificacion)}</span> ${c.calificacion.toFixed(1)} (${c.n_cal})` : SIN}</div></div></div>
    <dl class="kv"><div class="row"><dt>Años de experiencia</dt><dd>${val(c.anios_experiencia)}</dd></div>
    <div class="row"><dt>Bus asignado</dt><dd>${val(b.bus.placa)}</dd></div></dl>
    <p class="nota">🔒 Por privacidad no se muestran el documento ni el teléfono del chofer.</p>`;
}

function renderPasajeros() {
  const b = busSel(); const box = $('#p-pasajeros');
  if (!b) { box.innerHTML = vacioBox('Selecciona un bus disponible en la pestaña <b>Buses</b> para ver su ocupación.'); return; }
  if (b.pasajeros == null || !b.capacidad) {
    box.innerHTML = vacioBox('Todavía no hay dato de pasajeros para este bus (tabla <b>turnos</b>, campo pasajeros_actuales) o falta registrar su capacidad.'); return;
  }
  const pct = Math.min(100, Math.round(b.pasajeros * 100 / b.capacidad));
  const nivel = pct < 50 ? ['Baja ocupación', ''] : pct < 85 ? ['Ocupación media', 'warn'] : ['Casi lleno', 'bad'];
  box.innerHTML = `<dl class="kv">
      <div class="row"><dt>Pasajeros a bordo</dt><dd>${esc(b.pasajeros)}</dd></div>
      <div class="row"><dt>Capacidad total</dt><dd>${esc(b.capacidad)}</dd></div>
      <div class="row"><dt>Ocupación</dt><dd>${pct}% <span class="badge ${nivel[1]}">${nivel[0]}</span></dd></div></dl>
    <div class="barra" style="margin-top:14px"><i style="width:${pct}%"></i></div>`;
}

function renderHorarios() {
  const h = S.det.horarios;
  const ahora = new Date().toTimeString().slice(0, 5);
  const prox = h.find((x) => x.hora >= ahora);
  const tipo = { LV: 'lunes a viernes', SAB: 'sábados', DOM: 'domingos y festivos' }[S.det.dia_tipo] || '';
  $('#p-horarios').innerHTML = h.length
    ? `<p style="color:var(--ink2);margin-bottom:6px">Horarios de ${tipo}. El próximo aparece resaltado.</p><table><thead><tr><th>Hora</th><th>Paradero</th></tr></thead><tbody>${h.map((x) => `<tr class="${prox === x ? 'prox' : ''}"><td>${esc(x.hora)}</td><td>${esc(x.paradero)}</td></tr>`).join('')}</tbody></table>`
    : vacioBox('Aún no hay horarios registrados para hoy en esta ruta (tabla <b>horarios</b>).');
}

let puntajeSel = 0;
function renderCalif() {
  const c = S.det.calificacion, com = S.det.comentarios || [];
  const b = busSel();
  $('#p-calif').innerHTML = `
    <div style="display:flex;gap:18px;align-items:center;flex-wrap:wrap;margin-bottom:12px">
      <div class="score">${c.promedio != null ? c.promedio.toFixed(1) : '—'}</div>
      <div><span class="stars">${c.promedio != null ? stars(c.promedio) : '☆☆☆☆☆'}</span><br><small style="color:var(--ink2)">${c.total ? c.total + ' calificaciones' : 'Aún no hay calificaciones'}</small></div>
    </div>
    ${com.length ? com.map((x) => `<div class="coment"><span class="stars" style="font-size:1rem">${stars(x.puntaje)}</span> <small>${esc(x.fecha)}</small><br>${esc(x.comentario)}</div>`).join('') : vacioBox('Todavía no hay comentarios.')}
    <div class="rate">
      <b>Califica esta ruta</b>
      <div class="pick" id="pick">${[1, 2, 3, 4, 5].map((n) => `<button type="button" data-n="${n}" aria-label="${n} estrellas">★</button>`).join('')}</div>
      ${b ? `<select id="rateObj"><option value="ruta">Calificar solo la ruta</option><option value="bus">Calificar también el bus ${esc(b.bus.placa)}</option>${b.conductor ? '<option value="todo">Calificar también el bus y su chofer</option>' : ''}</select>` : ''}
      <textarea id="rateCom" rows="2" maxlength="500" placeholder="Comentario (opcional)"></textarea>
      <button class="btn primary" id="rateBtn" type="button">Enviar calificación</button>
      <div class="nota" id="rateMsg"></div>
    </div>`;
  puntajeSel = 0;
  document.querySelectorAll('#pick button').forEach((bt) => bt.addEventListener('click', () => {
    puntajeSel = Number(bt.dataset.n);
    document.querySelectorAll('#pick button').forEach((x) => x.classList.toggle('on', Number(x.dataset.n) <= puntajeSel));
  }));
  $('#rateBtn').addEventListener('click', enviarCalif);
}

async function enviarCalif() {
  const msg = $('#rateMsg');
  if (!puntajeSel) { msg.textContent = 'Elige de 1 a 5 estrellas.'; return; }
  const b = busSel(); const obj = $('#rateObj') ? $('#rateObj').value : 'ruta';
  const body = { accion: 'calificar', csrf: CSRF, ruta_id: S.ruta, puntaje: puntajeSel, comentario: $('#rateCom').value,
    bus_id: b && obj !== 'ruta' ? b.bus.id : null, conductor_id: b && b.conductor && obj === 'todo' ? b.conductor.id : null };
  try {
    const r = await fetch(location.pathname, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const j = await r.json();
    if (j.ok) { msg.textContent = '¡Gracias por tu calificación!'; const d = await api({ api: 'ruta', id: S.ruta }); if (d.ok) { S.det.calificacion = d.calificacion; const c = await api({ api: 'comentarios', ruta_id: S.ruta }); S.det.comentarios = c.ok ? c.comentarios : []; renderCalif(); $('#rateMsg').textContent = '¡Gracias por tu calificación!'; } }
    else msg.textContent = j.error || 'No se pudo enviar.';
  } catch (_) { msg.textContent = 'Error de conexión.'; }
}

/* ================= EVENTOS ================= */
document.querySelectorAll('#tabs .tab').forEach((t) => t.addEventListener('click', () => {
  document.querySelectorAll('#tabs .tab').forEach((x) => x.classList.toggle('on', x === t));
  document.querySelectorAll('.panel').forEach((p) => p.classList.toggle('on', p.id === 'p-' + t.dataset.t));
}));
$('#buscar').addEventListener('input', renderLista);
$('#btnBuscar').addEventListener('click', renderLista);
$('#selMuni').addEventListener('change', (e) => {
  const m = MUNICIPIOS.find((x) => String(x.id) === e.target.value);
  if (m) { avisar(''); $('#u-muni').textContent = m.nombre; $('#u-sub').textContent = 'Municipio elegido manualmente'; setMunicipio(m); }
});
$('#btnReubicar').addEventListener('click', escanear);

/* ================= INICIO ================= */
(function init() {
  renderLista();
  const g = ubicacionGuardada();
  if (g) aplicarUbicacion(g); else escanear();
})();
</script>
</body>
</html>