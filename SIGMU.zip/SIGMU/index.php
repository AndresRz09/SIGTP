<?php
declare(strict_types=1);
session_start();
date_default_timezone_set('America/Bogota');

/* ====================== CONFIGURACIÓN ====================== */
const DB_HOST = 'localhost';
const DB_NAME = 'sigmu_db';
const DB_USER = 'root';   // En producción usa un usuario con permisos mínimos (ver sigmu_db.sql)
const DB_PASS = '';

if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(16));
}
$csrf = $_SESSION['csrf'];

function e(?string $v): string
{
    return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function db(): ?PDO
{
    static $pdo = null;
    static $intentado = false;
    if ($intentado) {
        return $pdo;
    }
    $intentado = true;
    try {
        $pdo = new PDO(
            'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
            DB_USER,
            DB_PASS,
            [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]
        );
    } catch (Throwable $ex) {
        $pdo = null;
    }
    return $pdo;
}

/* ====================== ENDPOINT: guardar ubicación (opcional, anónima) ====================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && str_contains($_SERVER['CONTENT_TYPE'] ?? '', 'application/json')) {
    header('Content-Type: application/json; charset=utf-8');
    $in = json_decode(file_get_contents('php://input') ?: '', true);
    $in = is_array($in) ? $in : [];

    if (!hash_equals($_SESSION['csrf'], (string)($in['csrf'] ?? ''))) {
        http_response_code(403);
        echo json_encode(['ok' => false, 'error' => 'Token inválido']);
        exit;
    }

    $lat = $in['lat'] ?? null;
    $lng = $in['lng'] ?? null;
    // Rango aproximado de Colombia
    if (!is_numeric($lat) || !is_numeric($lng) || $lat < -4.5 || $lat > 13.6 || $lng < -79.5 || $lng > -66.5) {
        http_response_code(422);
        echo json_encode(['ok' => false, 'error' => 'Coordenadas fuera de rango']);
        exit;
    }

    $pdo = db();
    if (!$pdo) {
        http_response_code(503);
        echo json_encode(['ok' => false, 'error' => 'Base de datos no disponible']);
        exit;
    }

    try {
        $st = $pdo->prepare(
            'INSERT INTO ubicaciones_usuario (sesion_hash, latitud, longitud, precision_m, municipio, barrio, direccion)
             VALUES (:s, :la, :lo, :p, :m, :b, :d)'
        );
        $st->execute([
            ':s'  => hash('sha256', session_id()),
            ':la' => (float)$lat,
            ':lo' => (float)$lng,
            ':p'  => isset($in['precision']) ? (int)round((float)$in['precision']) : null,
            ':m'  => mb_substr((string)($in['municipio'] ?? ''), 0, 120),
            ':b'  => mb_substr((string)($in['barrio'] ?? ''), 0, 120),
            ':d'  => mb_substr((string)($in['direccion'] ?? ''), 0, 255),
        ]);
        echo json_encode(['ok' => true]);
    } catch (Throwable $ex) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'error' => 'No se pudo guardar']);
    }
    exit;
}

/* ====================== DATOS (BD con respaldo de demostración) ====================== */
$pdo  = db();
$dbOk = $pdo !== null;

$contenido = [
    ['clave' => 'mision', 'titulo' => 'Nuestra Misión', 'icono' => '🎯',
     'texto' => 'Mejorar la experiencia y la seguridad del transporte público en Bogotá con un sistema híbrido de información en tiempo real: app con GPS del conductor, panel en el paradero y avisos sin internet (SMS/BLE).'],
    ['clave' => 'bienvenida', 'titulo' => '¡Bienvenidos a SIGMU!', 'icono' => '🚌',
     'texto' => 'Consulta buses, horarios y paraderos cercanos, y conoce en qué municipio y barrio te encuentras, todo desde un solo lugar.'],
    ['clave' => 'vision', 'titulo' => 'Nuestra Visión', 'icono' => '🌟',
     'texto' => 'Ser un referente de movilidad inteligente e incluyente en Colombia, con paraderos bien iluminados, señalizados y seguros para todas las personas.'],
    ['clave' => 'informacion', 'titulo' => 'Información del Sistema', 'icono' => '📡',
     'texto' => 'SIGMU combina geolocalización, mapas y datos de paraderos y rutas. También funciona para quienes no tienen conexión estable a internet.'],
];
$paraderos = [
    ['codigo' => 'PAR-001', 'nombre' => 'Portal Norte', 'direccion' => 'Autopista Norte con Calle 170', 'municipio' => 'Bogotá D.C.', 'sector' => 'Usaquén', 'latitud' => 4.7545, 'longitud' => -74.0457, 'iluminacion' => 1, 'senalizacion' => 1, 'estado' => 'activo'],
    ['codigo' => 'PAR-002', 'nombre' => 'Calle 100', 'direccion' => 'Autopista Norte con Calle 100', 'municipio' => 'Bogotá D.C.', 'sector' => 'Chicó', 'latitud' => 4.6862, 'longitud' => -74.0576, 'iluminacion' => 1, 'senalizacion' => 1, 'estado' => 'activo'],
    ['codigo' => 'PAR-003', 'nombre' => 'Plaza de Bolívar', 'direccion' => 'Carrera 7 con Calle 11', 'municipio' => 'Bogotá D.C.', 'sector' => 'La Candelaria', 'latitud' => 4.5981, 'longitud' => -74.0760, 'iluminacion' => 1, 'senalizacion' => 0, 'estado' => 'activo'],
    ['codigo' => 'PAR-007', 'nombre' => 'Parque Principal Zipaquirá', 'direccion' => 'Centro de Zipaquirá', 'municipio' => 'Zipaquirá', 'sector' => 'Centro', 'latitud' => 5.0229, 'longitud' => -74.0048, 'iluminacion' => 1, 'senalizacion' => 1, 'estado' => 'activo'],
];
$horarios = [
    ['codigo' => 'SIG-01', 'ruta' => 'Portal Norte – Portal Sur', 'paradero' => 'Portal Norte', 'hora' => '06:00'],
    ['codigo' => 'SIG-02', 'ruta' => 'Portal 80 – Plaza de Bolívar', 'paradero' => 'Plaza de Bolívar', 'hora' => '06:15'],
    ['codigo' => 'SIG-03', 'ruta' => 'Terminal Salitre – Calle 100', 'paradero' => 'Calle 100', 'hora' => '06:30'],
];
$rutasActivas = 3;
$horariosTitulo = 'Próximas salidas (demostración)';

if ($dbOk) {
    try {
        $r = $pdo->query("SELECT clave, titulo, texto, icono FROM contenido_sistema WHERE activo = 1 ORDER BY orden")->fetchAll();
        if ($r) {
            $contenido = $r;
        }

        $r = $pdo->query(
            "SELECT p.codigo, p.nombre, p.direccion, m.nombre AS municipio, p.sector,
                    p.latitud, p.longitud, p.tiene_iluminacion AS iluminacion,
                    p.tiene_senalizacion AS senalizacion, p.estado
             FROM paraderos p
             JOIN municipios m ON m.id = p.municipio_id
             WHERE p.estado <> 'inactivo'
             ORDER BY p.nombre"
        )->fetchAll();
        if ($r) {
            $paraderos = $r;
        }

        $rutasActivas = (int)$pdo->query("SELECT COUNT(*) FROM rutas WHERE estado = 'activa'")->fetchColumn();

        $dow  = (int)date('N');
        $tipo = $dow === 7 ? 'DOM' : ($dow === 6 ? 'SAB' : 'LV');
        $sql  = "SELECT r.codigo, r.nombre AS ruta, p.nombre AS paradero, TIME_FORMAT(h.hora_salida, '%H:%i') AS hora
                 FROM horarios h
                 JOIN rutas r ON r.id = h.ruta_id
                 JOIN paraderos p ON p.id = h.paradero_id
                 WHERE h.dia_tipo = :t AND r.estado = 'activa' %s
                 ORDER BY h.hora_salida LIMIT 8";

        $st = $pdo->prepare(sprintf($sql, 'AND h.hora_salida >= :ahora'));
        $st->execute([':t' => $tipo, ':ahora' => date('H:i:s')]);
        $r = $st->fetchAll();
        $horariosTitulo = 'Próximas salidas de hoy';
        if (!$r) {
            $st = $pdo->prepare(sprintf($sql, ''));
            $st->execute([':t' => $tipo]);
            $r = $st->fetchAll();
            $horariosTitulo = 'Primeras salidas del día';
        }
        if ($r) {
            $horarios = $r;
        }
    } catch (Throwable $ex) {
        $dbOk = false; // Se mantienen los datos de demostración
    }
}

$startSlide = 0;
foreach ($contenido as $i => $c) {
    if ($c['clave'] === 'bienvenida') {
        $startSlide = $i;
    }
}

$paraderosJs = array_map(static fn($p) => [
    'codigo'      => $p['codigo'],
    'nombre'      => $p['nombre'],
    'direccion'   => $p['direccion'],
    'municipio'   => $p['municipio'],
    'sector'      => $p['sector'],
    'lat'         => (float)$p['latitud'],
    'lng'         => (float)$p['longitud'],
    'iluminacion' => (int)$p['iluminacion'],
    'senalizacion' => (int)$p['senalizacion'],
    'estado'      => $p['estado'],
], $paraderos);
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SIGMU – Sistema de Transporte</title>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<style>
:root{
  --bg:#eaf4fb; --bg2:#f6fbff; --ink:#27425a; --ink2:#5b7a93;
  --blue:#59b2e6; --blue-d:#3b8fc4; --mint:#7fdcc4; --mint-d:#4cb99f;
  --sun:#ffd98a; --sun-d:#e9b84f; --coral:#ff9f8a; --lav:#bfb0f5;
  --card:#ffffffd9; --radius:22px;
  --shadow:0 2px 0 #fff inset, 0 18px 30px -12px rgba(59,143,196,.35), 0 6px 10px -4px rgba(39,66,90,.12);
}
*{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{
  font-family:"Segoe UI",system-ui,-apple-system,Roboto,Arial,sans-serif;color:var(--ink);
  background:
    radial-gradient(900px 500px at 10% -10%, #cdeafc 0, transparent 60%),
    radial-gradient(800px 500px at 100% 0%, #dcf7ee 0, transparent 55%),
    radial-gradient(700px 500px at 50% 110%, #fdf1d3 0, transparent 60%),
    var(--bg);
  min-height:100vh; overflow-x:hidden;
}
/* Formas flotantes 3D */
.blob{position:fixed;z-index:0;border-radius:50%;filter:blur(2px);opacity:.55;animation:float 12s ease-in-out infinite;pointer-events:none}
.blob.b1{width:180px;height:180px;left:-50px;top:30%;background:radial-gradient(circle at 30% 30%,#fff,var(--lav))}
.blob.b2{width:130px;height:130px;right:-30px;top:55%;background:radial-gradient(circle at 30% 30%,#fff,var(--sun));animation-delay:-4s}
.blob.b3{width:90px;height:90px;left:45%;bottom:-30px;background:radial-gradient(circle at 30% 30%,#fff,var(--mint));animation-delay:-8s}
@keyframes float{0%,100%{transform:translateY(0) rotate(0)}50%{transform:translateY(-26px) rotate(12deg)}}

/* ---------- Barra de navegación ---------- */
header.nav{
  position:sticky;top:0;z-index:1000;display:flex;align-items:center;gap:18px;flex-wrap:wrap;
  padding:12px clamp(14px,4vw,40px);
  background:linear-gradient(180deg,#ffffffee,#f1f9ffee);backdrop-filter:blur(10px);
  box-shadow:0 10px 25px -14px rgba(59,143,196,.5);border-bottom:1px solid #fff;
}
.logo{display:flex;align-items:center;gap:10px;font-weight:800;font-size:1.35rem;letter-spacing:.04em;color:var(--blue-d);text-decoration:none}
.logo .cube{
  width:40px;height:40px;border-radius:12px;display:grid;place-items:center;font-size:1.3rem;
  background:linear-gradient(135deg,var(--blue),var(--mint));color:#fff;
  box-shadow:0 5px 0 var(--blue-d),0 12px 18px -6px rgba(59,143,196,.6);transform:rotate(-6deg);
}
nav.menu{display:flex;gap:8px;flex-wrap:wrap;margin-left:auto;align-items:center}
.btn,.menu a{
  display:inline-flex;align-items:center;gap:8px;text-decoration:none;cursor:pointer;border:0;font:inherit;font-weight:600;
  color:var(--ink);padding:9px 18px;border-radius:14px;background:#fff;
  box-shadow:0 4px 0 #cfe5f4,0 10px 16px -8px rgba(59,143,196,.45);
  transition:transform .15s,box-shadow .15s,background .2s;
}
.btn:hover,.menu a:hover{transform:translateY(-2px);background:#f4fbff}
.btn:active,.menu a:active{transform:translateY(3px);box-shadow:0 1px 0 #cfe5f4}
.menu a.primary,.btn.primary{background:linear-gradient(135deg,var(--blue),#7cc8f0);color:#fff;box-shadow:0 4px 0 var(--blue-d),0 12px 18px -8px rgba(59,143,196,.7)}
.btn.mint{background:linear-gradient(135deg,var(--mint),#a6ebd8);color:#14513f;box-shadow:0 4px 0 var(--mint-d),0 12px 18px -8px rgba(76,185,159,.7)}
.btn.sun{background:linear-gradient(135deg,var(--sun),#ffe9b8);color:#6a4d0b;box-shadow:0 4px 0 var(--sun-d),0 12px 18px -8px rgba(233,184,79,.7)}

/* ---------- Diseño general ---------- */
.layout{position:relative;z-index:1;display:grid;grid-template-columns:260px 1fr;gap:26px;max-width:1360px;margin:26px auto;padding:0 clamp(14px,3vw,30px)}
aside.side{position:sticky;top:88px;align-self:start;display:flex;flex-direction:column;gap:18px}
.card{background:var(--card);border-radius:var(--radius);padding:22px;box-shadow:var(--shadow);border:1px solid #fff;backdrop-filter:blur(6px)}
.card h2,.card h3{margin-bottom:12px}
.side h3{font-size:1.05rem;color:var(--blue-d)}
.side ul{list-style:none;display:flex;flex-direction:column;gap:8px}
.side li a{
  display:flex;gap:10px;align-items:center;padding:10px 14px;border-radius:14px;text-decoration:none;color:var(--ink);font-weight:600;
  background:linear-gradient(135deg,#f3faff,#e6f4fc);box-shadow:0 3px 0 #d3e8f5;transition:.2s;
}
.side li a:hover,.side li a.active{transform:translateX(6px);background:linear-gradient(135deg,var(--blue),#8bd0f4);color:#fff;box-shadow:0 3px 0 var(--blue-d)}
main{display:flex;flex-direction:column;gap:30px;min-width:0}
section{scroll-margin-top:96px}
.sec-title{display:flex;align-items:center;gap:12px;font-size:1.5rem;margin-bottom:16px}
.sec-title .ico{width:44px;height:44px;border-radius:14px;display:grid;place-items:center;background:linear-gradient(135deg,var(--sun),#ffeab9);box-shadow:0 4px 0 var(--sun-d)}
.badge{display:inline-block;font-size:.78rem;font-weight:700;padding:4px 10px;border-radius:99px;background:#e1f5ee;color:#1d7a62}
.badge.warn{background:#fff1d6;color:#8a6410}
.badge.bad{background:#ffe3dc;color:#a8432d}

/* ---------- Slider 3D ---------- */
.hero{padding:26px 10px 18px}
.hero-top{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;padding:0 14px}
.chips{display:flex;gap:10px;flex-wrap:wrap}
.chip{padding:6px 14px;border-radius:99px;background:#fff;font-weight:700;font-size:.85rem;box-shadow:0 3px 0 #d6e9f6}
.stage{position:relative;height:370px;perspective:1500px;overflow:hidden;margin-top:6px}
.slide{
  position:absolute;top:50%;left:50%;width:min(520px,76%);height:290px;padding:28px 30px;border-radius:28px;
  display:flex;flex-direction:column;justify-content:center;gap:10px;color:#24455c;
  transform-style:preserve-3d;transition:transform .9s cubic-bezier(.2,.8,.2,1),opacity .7s;
  box-shadow:0 2px 0 #ffffffb0 inset,0 26px 40px -18px rgba(39,66,90,.45),0 10px 0 -4px rgba(255,255,255,.5);
  border:1px solid #fff;
}
.slide .big{font-size:3rem;filter:drop-shadow(0 8px 6px rgba(0,0,0,.15));transform:translateZ(40px)}
.slide h3{font-size:1.6rem;transform:translateZ(25px)}
.slide p{line-height:1.55;font-size:1.02rem;transform:translateZ(15px)}
.slide.mision{background:linear-gradient(135deg,#d2f1ff,#a7defa)}
.slide.bienvenida{background:linear-gradient(135deg,#fff0c8,#ffd5a1)}
.slide.vision{background:linear-gradient(135deg,#d9f9ec,#a8ecd3)}
.slide.informacion{background:linear-gradient(135deg,#e8e0ff,#cfc2fa)}
.slide:not(.active){filter:saturate(.8)}
.ctrl{display:flex;justify-content:center;align-items:center;gap:14px;margin-top:6px}
.dots{display:flex;gap:8px}
.dots button{width:12px;height:12px;border-radius:50%;border:0;background:#c7deee;cursor:pointer;box-shadow:0 2px 0 #aecbdf;transition:.3s}
.dots button.on{width:32px;border-radius:99px;background:var(--blue)}
.arrow{width:44px;height:44px;border-radius:50%;padding:0;justify-content:center;font-size:1.3rem}

/* ---------- Buses / horarios ---------- */
.twocol{display:grid;grid-template-columns:1.2fr 1fr;gap:22px}
table{width:100%;border-collapse:separate;border-spacing:0 8px}
th{font-size:.8rem;text-transform:uppercase;letter-spacing:.06em;color:var(--ink2);text-align:left;padding:0 12px}
td{padding:11px 12px;background:#f3faff;font-size:.95rem}
td:first-child{border-radius:12px 0 0 12px;font-weight:800;color:var(--blue-d)}
td:last-child{border-radius:0 12px 12px 0}
.hora{font-weight:800;font-variant-numeric:tabular-nums;color:#1d7a62}
.tilt{transform-style:preserve-3d;transition:transform .2s ease-out,box-shadow .2s}
.tilt-wrap{perspective:1100px}

/* ---------- Ubicación y mapa ---------- */
.geo{display:grid;grid-template-columns:1.6fr 1fr;gap:22px}
#map{height:460px;border-radius:20px;box-shadow:0 0 0 6px #fff,0 18px 30px -14px rgba(59,143,196,.5);z-index:1}
.datos dl{display:grid;gap:10px;margin:14px 0}
.datos .row{background:linear-gradient(135deg,#f6fbff,#e9f5fd);border-radius:14px;padding:10px 14px;box-shadow:0 3px 0 #d6e9f6}
.datos dt{font-size:.75rem;text-transform:uppercase;letter-spacing:.06em;color:var(--ink2);font-weight:700}
.datos dd{font-weight:700;font-size:1.02rem;word-break:break-word}
.estado{padding:10px 14px;border-radius:14px;font-weight:600;font-size:.92rem;background:#eef7fd;margin-bottom:6px}
.estado.ok{background:#e1f7ef;color:#1d7a62}
.estado.err{background:#ffe8e1;color:#a8432d}
.opt{display:flex;gap:8px;align-items:center;font-size:.88rem;color:var(--ink2);margin-top:10px}
.pin{font-size:26px;filter:drop-shadow(0 6px 3px rgba(0,0,0,.3));text-align:center;line-height:1}

/* ---------- Información / Seguridad / Paraderos ---------- */
.grid3{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:20px}
.info-card{padding:22px;border-radius:22px;background:#fff;box-shadow:var(--shadow);border:1px solid #fff}
.info-card .e{font-size:2.2rem;display:block;margin-bottom:8px;transform:translateZ(30px)}
.info-card h3{margin-bottom:6px}
.info-card p{color:var(--ink2);line-height:1.5;font-size:.95rem}
.near{display:grid;gap:10px;margin-top:10px}
.near .item{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:12px 16px;border-radius:16px;background:#f3faff;box-shadow:0 3px 0 #d6e9f6;cursor:pointer;transition:.2s}
.near .item:hover{transform:translateY(-3px);background:#e8f6ff}
.near small{color:var(--ink2)}
.dist{font-weight:800;color:var(--blue-d);white-space:nowrap}
footer{position:relative;z-index:1;text-align:center;color:var(--ink2);padding:30px 14px 40px;font-size:.9rem}
.demo{background:#fff1d6;color:#8a6410;padding:8px 16px;text-align:center;font-weight:600;font-size:.88rem}

/* ---------- Manual de usuario (modal) ---------- */
dialog{border:0;border-radius:26px;padding:0;width:min(680px,92vw);box-shadow:0 30px 70px -20px rgba(39,66,90,.55);background:var(--bg2);color:var(--ink)}
dialog::backdrop{background:rgba(39,66,90,.45);backdrop-filter:blur(3px)}
.dlg-head{display:flex;justify-content:space-between;align-items:center;padding:20px 26px;background:linear-gradient(135deg,var(--blue),var(--mint));color:#fff}
.dlg-body{padding:22px 26px;max-height:62vh;overflow:auto}
.steps{counter-reset:s;list-style:none;display:grid;gap:12px}
.steps li{counter-increment:s;position:relative;padding:14px 16px 14px 60px;background:#fff;border-radius:16px;box-shadow:0 3px 0 #d6e9f6;line-height:1.5}
.steps li::before{content:counter(s);position:absolute;left:14px;top:12px;width:34px;height:34px;border-radius:50%;display:grid;place-items:center;font-weight:800;color:#fff;background:linear-gradient(135deg,var(--blue),var(--mint));box-shadow:0 3px 0 var(--blue-d)}
.dlg-body h4{margin:18px 0 8px;color:var(--blue-d)}
.dlg-foot{padding:14px 26px 22px;text-align:right}

@media (max-width:1000px){
  .layout{grid-template-columns:1fr}
  aside.side{position:static}
  .side ul{flex-direction:row;flex-wrap:wrap}
  .twocol,.geo{grid-template-columns:1fr}
  nav.menu{margin-left:0}
}
@media (max-width:560px){.stage{height:340px}.slide{height:280px;padding:22px}#map{height:360px}}
@media (prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}
</style>
</head>
<body>
<div class="blob b1"></div><div class="blob b2"></div><div class="blob b3"></div>

<?php if (!$dbOk): ?>
<div class="demo">⚠️ Modo demostración: no se pudo conectar con la base de datos <b>sigmu_db</b>. Importa <b>sigmu_db.sql</b> y revisa la configuración en index.php.</div>
<?php endif; ?>

<!-- ============ BARRA DE NAVEGACIÓN ============ -->
<header class="nav">
  <a class="logo" href="#inicio"><span class="cube">🚌</span> SIGMU</a>
  <nav class="menu" aria-label="Navegación principal">
    <a href="#inicio" class="primary">🏠 Inicio</a>
    <a href="informacion Urbana.php">🏙️ Información Urbana</a>
    <a href="#pars">🚏 PARS</a>
    <a href="login.php" title="Iniciar sesión">🔐 IS</a>
  </nav>
</header>

<div class="layout">
  <!-- ============ LATERAL: ÍNDICE + MANUAL ============ -->
  <aside class="side">
    <div class="card">
      <h3>📚 Índice</h3>
      <ul id="indice">
        <li><a href="#inicio">▸ Inicio</a></li>
        <li><a href="#ubicacion">▸ Ubicación y mapa</a></li>
        <li><a href="#informacion">▸ Información</a></li>
        <li><a href="#seguridad">▸ Seguridad</a></li>
        <li><a href="#pars">▸ PARS</a></li>
      </ul>
    </div>
    <div class="card" style="text-align:center">
      <h3>📖 Manual de Usuario</h3>
      <p style="color:var(--ink2);font-size:.9rem;margin-bottom:12px">Aprende a usar SIGMU en pocos pasos.</p>
      <button class="btn sun" id="abrirManual" type="button">Abrir manual</button>
    </div>
  </aside>

  <main>
    <!-- ============ SLIDER: MISIÓN · BIENVENIDOS · VISIÓN ============ -->
    <section id="inicio" class="card hero">
      <div class="hero-top">
        <div class="sec-title" style="margin:0"><span class="ico">🚏</span> Sistema de Transporte</div>
        <div class="chips">
          <span class="chip">🚏 <?= count($paraderos) ?> paraderos</span>
          <span class="chip">🛣️ <?= (int)$rutasActivas ?> rutas activas</span>
        </div>
      </div>

      <div class="stage" id="stage" data-start="<?= (int)$startSlide ?>" aria-roledescription="carrusel">
        <?php foreach ($contenido as $c): ?>
          <article class="slide <?= e($c['clave']) ?>">
            <span class="big"><?= e($c['icono']) ?></span>
            <h3><?= e($c['titulo']) ?></h3>
            <p><?= e($c['texto']) ?></p>
          </article>
        <?php endforeach; ?>
      </div>

      <div class="ctrl">
        <button class="btn arrow" id="prev" type="button" aria-label="Anterior">‹</button>
        <div class="dots" id="dots"></div>
        <button class="btn arrow" id="next" type="button" aria-label="Siguiente">›</button>
      </div>
    </section>

    <!-- ============ INFORMACIÓN BUSES – HORARIOS ============ -->
    <section id="buses" class="twocol">
      <div class="card">
        <div class="sec-title"><span class="ico">🕒</span> Información de buses y horarios</div>
        <p style="color:var(--ink2);margin:-6px 0 8px"><?= e($horariosTitulo) ?></p>
        <table>
          <thead><tr><th>Ruta</th><th>Recorrido</th><th>Paradero</th><th>Hora</th></tr></thead>
          <tbody>
          <?php foreach ($horarios as $h): ?>
            <tr>
              <td><?= e($h['codigo']) ?></td>
              <td><?= e($h['ruta']) ?></td>
              <td><?= e($h['paradero']) ?></td>
              <td class="hora"><?= e($h['hora']) ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <div class="tilt-wrap">
        <div class="card tilt" style="height:100%">
          <div class="sec-title"><span class="ico">📡</span> ¿Sin internet?</div>
          <p style="line-height:1.6;color:var(--ink2)">SIGMU contempla avisos de respaldo por <b>SMS</b> o <b>Bluetooth (BLE)</b> y un <b>panel físico en el paradero</b>, para que quienes no tienen datos móviles también reciban información del bus.</p>
          <div style="margin-top:14px;display:flex;gap:8px;flex-wrap:wrap">
            <span class="badge">📱 App del conductor (GPS)</span>
            <span class="badge">🪧 Panel en paradero</span>
            <span class="badge">✉️ SMS / BLE</span>
          </div>
        </div>
      </div>
    </section>

    <!-- ============ INFORMACIÓN DE UBICACIÓN + MAPA + DATOS ============ -->
    <section id="ubicacion">
      <div class="sec-title"><span class="ico">📍</span> Información de ubicación</div>
      <div class="geo">
        <div class="card">
          <h3>🗺️ Mapa</h3>
          <div id="map"></div>
        </div>
        <div class="card datos">
          <h3>📊 Datos</h3>
          <button class="btn primary" id="escanear" type="button">📡 Escanear ubicación</button>
          <div class="estado" id="estado" style="margin-top:14px">Esperando permiso de ubicación…</div>
          <dl>
            <div class="row"><dt>Latitud</dt><dd id="d-lat">—</dd></div>
            <div class="row"><dt>Longitud</dt><dd id="d-lng">—</dd></div>
            <div class="row"><dt>Precisión</dt><dd id="d-pre">—</dd></div>
            <div class="row"><dt>Municipio</dt><dd id="d-mun">—</dd></div>
            <div class="row"><dt>Barrio / sector</dt><dd id="d-bar">—</dd></div>
            <div class="row"><dt>Dirección aproximada</dt><dd id="d-dir">—</dd></div>
          </dl>
          <label class="opt"><input type="checkbox" id="guardar"> Guardar mi ubicación de forma anónima para mejorar el sistema</label>
        </div>
      </div>
    </section>

    <!-- ============ INFORMACIÓN URBANA ============ -->
    <section id="informacion">
      <div class="sec-title"><span class="ico">🏙️</span> Información urbana</div>
      <div class="grid3 tilt-wrap">
        <div class="info-card tilt"><span class="e">🧭</span><h3>Ubícate</h3><p>Detectamos tus coordenadas y te decimos en qué municipio y barrio estás, resaltando sus límites en el mapa.</p></div>
        <div class="info-card tilt"><span class="e">🚍</span><h3>Rutas y horarios</h3><p>Consulta las próximas salidas de buses en los paraderos del sistema.</p></div>
        <div class="info-card tilt"><span class="e">🚏</span><h3>Paraderos cercanos</h3><p>Calculamos qué paraderos tienes más cerca y su estado de iluminación y señalización.</p></div>
      </div>
    </section>

    <!-- ============ SEGURIDAD ============ -->
    <section id="seguridad">
      <div class="sec-title"><span class="ico">🛡️</span> Seguridad en los paraderos</div>
      <div class="grid3 tilt-wrap">
        <div class="info-card tilt"><span class="e">💡</span><h3>Iluminación</h3><p>Priorizamos paraderos bien iluminados. Cada paradero indica si cuenta con iluminación adecuada.</p></div>
        <div class="info-card tilt"><span class="e">🪧</span><h3>Señalización</h3><p>Identificamos paraderos con señalización deteriorada o ausente para facilitar su mejora.</p></div>
        <div class="info-card tilt"><span class="e">🤝</span><h3>Seguridad percibida</h3><p>Espera en zonas iluminadas y concurridas, y avisa cualquier novedad a las autoridades (línea 123).</p></div>
      </div>
    </section>

    <!-- ============ PARS (PARADEROS) ============ -->
    <section id="pars" class="card">
      <div class="sec-title"><span class="ico">🚏</span> PARS · Paraderos</div>
      <p style="color:var(--ink2)" id="near-txt">Escanea tu ubicación para ver los paraderos más cercanos.</p>
      <div class="near" id="near"></div>
      <h3 style="margin-top:22px">Todos los paraderos</h3>
      <div class="near" id="all"></div>
    </section>
  </main>
</div>

<footer>SIGMU · Sistema de Transporte · Proyecto académico de Ingeniería de Sistemas<br>Mapas © colaboradores de OpenStreetMap</footer>

<!-- ============ MANUAL DE USUARIO ============ -->
<dialog id="manual">
  <div class="dlg-head"><h3>📖 Manual de Usuario – SIGMU</h3><button class="btn arrow" id="cerrarManual1" type="button" aria-label="Cerrar">✕</button></div>
  <div class="dlg-body">
    <ol class="steps">
      <li><b>Inicio:</b> el carrusel muestra la misión, la visión y la información del sistema. Se mueve solo; usa las flechas o los puntos para cambiar de tarjeta.</li>
      <li><b>Escanear ubicación:</b> pulsa el botón y acepta el permiso del navegador. Verás tus coordenadas, el municipio y el barrio en el panel <i>Datos</i>.</li>
      <li><b>Mapa:</b> tu posición aparece con un marcador, y el contorno del municipio se resalta en el mapa. Puedes acercar, alejar y mover el mapa.</li>
      <li><b>PARS:</b> consulta los paraderos más cercanos, su distancia y si tienen iluminación y señalización. Toca uno para verlo en el mapa.</li>
      <li><b>Buses y horarios:</b> revisa las próximas salidas de cada ruta en la tabla de información.</li>
      <li><b>Iniciar sesión (IS):</b> accede con tu cuenta para funciones adicionales.</li>
    </ol>
    <h4>Preguntas frecuentes</h4>
    <p><b>¿No me detecta la ubicación?</b> Activa el GPS, permite el acceso a la ubicación en tu navegador y pulsa de nuevo «Escanear ubicación». La geolocalización requiere conexión segura (HTTPS) o localhost.</p>
    <h4>Privacidad</h4>
    <p>Tu ubicación solo se guarda si marcas la casilla de «Guardar mi ubicación de forma anónima». No se asocia a tu nombre.</p>
  </div>
  <div class="dlg-foot"><button class="btn primary" id="cerrarManual2" type="button">Entendido</button></div>
</dialog>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
const PARADEROS = <?= json_encode($paraderosJs, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
const CSRF = <?= json_encode($csrf) ?>;
const $ = (s) => document.querySelector(s);
const esc = (t) => String(t ?? '').replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/* ================= SLIDER 3D AUTOMÁTICO ================= */
(() => {
  const stage = $('#stage');
  const slides = [...stage.querySelectorAll('.slide')];
  const dotsBox = $('#dots');
  const n = slides.length;
  let cur = Math.min(parseInt(stage.dataset.start || '0', 10), n - 1);
  let timer = null;

  slides.forEach((_, i) => {
    const b = document.createElement('button');
    b.type = 'button'; b.setAttribute('aria-label', 'Ir a la tarjeta ' + (i + 1));
    b.addEventListener('click', () => { cur = i; render(); restart(); });
    dotsBox.appendChild(b);
  });

  function render() {
    slides.forEach((s, i) => {
      let d = i - cur;
      if (d > n / 2) d -= n;
      if (d < -n / 2) d += n;
      const a = Math.abs(d), vis = a <= 1;
      s.style.transform = `translate(-50%,-50%) translateX(${d * 68}%) translateZ(${-a * 150}px) rotateY(${-d * 34}deg) scale(${1 - a * 0.08})`;
      s.style.opacity = vis ? (a === 0 ? 1 : 0.75) : 0;
      s.style.zIndex = 10 - a;
      s.style.pointerEvents = vis ? 'auto' : 'none';
      s.setAttribute('aria-hidden', a === 0 ? 'false' : 'true');
    });
    [...dotsBox.children].forEach((b, i) => b.classList.toggle('on', i === cur));
  }
  const go = (k) => { cur = (cur + k + n) % n; render(); };
  const start = () => { timer = setInterval(() => go(1), 5000); };
  const stop = () => { clearInterval(timer); timer = null; };
  const restart = () => { stop(); start(); };

  $('#prev').addEventListener('click', () => { go(-1); restart(); });
  $('#next').addEventListener('click', () => { go(1); restart(); });
  stage.addEventListener('mouseenter', stop);
  stage.addEventListener('mouseleave', start);
  stage.addEventListener('touchstart', stop, { passive: true });
  stage.addEventListener('touchend', start, { passive: true });
  render(); start();
})();

/* ================= EFECTO 3D (tilt) EN TARJETAS ================= */
document.querySelectorAll('.tilt').forEach((el) => {
  el.addEventListener('mousemove', (ev) => {
    const r = el.getBoundingClientRect();
    const x = (ev.clientX - r.left) / r.width - 0.5;
    const y = (ev.clientY - r.top) / r.height - 0.5;
    el.style.transform = `rotateY(${x * 12}deg) rotateX(${-y * 12}deg) translateZ(8px)`;
  });
  el.addEventListener('mouseleave', () => { el.style.transform = ''; });
});

/* ================= MANUAL ================= */
const manual = $('#manual');
$('#abrirManual').addEventListener('click', () => manual.showModal());
$('#cerrarManual1').addEventListener('click', () => manual.close());
$('#cerrarManual2').addEventListener('click', () => manual.close());
manual.addEventListener('click', (e) => { if (e.target === manual) manual.close(); });

/* ================= ÍNDICE: resaltar sección activa ================= */
(() => {
  const links = [...document.querySelectorAll('#indice a')];
  const map = new Map(links.map((a) => [a.getAttribute('href').slice(1), a]));
  const io = new IntersectionObserver((entries) => {
    entries.forEach((en) => {
      if (en.isIntersecting && map.has(en.target.id)) {
        links.forEach((l) => l.classList.remove('active'));
        map.get(en.target.id).classList.add('active');
      }
    });
  }, { rootMargin: '-35% 0px -55% 0px' });
  map.forEach((_, id) => { const s = document.getElementById(id); if (s) io.observe(s); });
})();

/* ================= MAPA ================= */
const map = L.map('map').setView([4.7110, -74.0721], 11);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
}).addTo(map);

const capaParaderos = L.layerGroup().addTo(map);
const capaLimite = L.layerGroup().addTo(map);
const capaUsuario = L.layerGroup().addTo(map);
const emojiIcon = (emoji) => L.divIcon({ html: `<div class="pin">${emoji}</div>`, className: '', iconSize: [30, 30], iconAnchor: [15, 28], popupAnchor: [0, -26] });

PARADEROS.forEach((p) => {
  L.marker([p.lat, p.lng], { icon: emojiIcon('🚏') }).addTo(capaParaderos)
    .bindPopup(`<b>${esc(p.nombre)}</b><br>${esc(p.direccion)}<br><small>${esc(p.municipio)} · ${esc(p.sector)}</small><br>💡 ${p.iluminacion ? 'Con iluminación' : 'Sin iluminación'} · 🪧 ${p.senalizacion ? 'Señalizado' : 'Sin señalización'}`);
});

/* ================= LISTAS DE PARADEROS ================= */
const fmtDist = (m) => (m < 1000 ? Math.round(m) + ' m' : (m / 1000).toFixed(1) + ' km');
function haversine(a, b, c, d) {
  const R = 6371000, rad = (x) => x * Math.PI / 180;
  const dLat = rad(c - a), dLon = rad(d - b);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a)) * Math.cos(rad(c)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}
function itemParadero(p, dist) {
  const el = document.createElement('div');
  el.className = 'item'; el.tabIndex = 0;
  el.innerHTML = `<div><b>${esc(p.nombre)}</b><br><small>${esc(p.direccion)} · ${esc(p.municipio)}</small><br>
      <span class="badge ${p.iluminacion ? '' : 'warn'}">💡 ${p.iluminacion ? 'Iluminado' : 'Poca luz'}</span>
      <span class="badge ${p.senalizacion ? '' : 'warn'}">🪧 ${p.senalizacion ? 'Señalizado' : 'Sin señal'}</span>
      ${p.estado !== 'activo' ? `<span class="badge bad">${esc(p.estado)}</span>` : ''}</div>
      <div class="dist">${dist != null ? fmtDist(dist) : '→ mapa'}</div>`;
  const ver = () => { document.getElementById('ubicacion').scrollIntoView(); map.flyTo([p.lat, p.lng], 16); };
  el.addEventListener('click', ver);
  el.addEventListener('keydown', (e) => { if (e.key === 'Enter') ver(); });
  return el;
}
const allBox = $('#all');
PARADEROS.forEach((p) => allBox.appendChild(itemParadero(p, null)));

function mostrarCercanos(lat, lng) {
  const lista = PARADEROS.map((p) => ({ p, d: haversine(lat, lng, p.lat, p.lng) })).sort((x, y) => x.d - y.d).slice(0, 5);
  const box = $('#near'); box.innerHTML = '';
  lista.forEach(({ p, d }) => box.appendChild(itemParadero(p, d)));
  $('#near-txt').textContent = 'Los 5 paraderos más cercanos a tu ubicación:';
}

/* ================= GEOLOCALIZACIÓN ================= */
function setEstado(tipo, msg) {
  const el = $('#estado');
  el.className = 'estado' + (tipo === 'ok' ? ' ok' : tipo === 'err' ? ' err' : '');
  el.textContent = msg;
}

async function nominatim(lat, lng, zoom, poligono) {
  let url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&addressdetails=1&accept-language=es&lat=${lat}&lon=${lng}&zoom=${zoom}`;
  if (poligono) url += '&polygon_geojson=1&polygon_threshold=0.0008';
  const r = await fetch(url, { headers: { Accept: 'application/json' } });
  if (!r.ok) throw new Error('HTTP ' + r.status);
  return r.json();
}

function dibujarLimite(muni, lat, lng) {
  capaLimite.clearLayers();
  const g = muni && muni.geojson;
  if (g && (g.type === 'Polygon' || g.type === 'MultiPolygon')) {
    const capa = L.geoJSON(g, {
      style: { color: '#3b8fc4', weight: 3, dashArray: '8 6', fillColor: '#7fdcc4', fillOpacity: 0.18 }
    }).addTo(capaLimite);
    map.fitBounds(capa.getBounds(), { padding: [20, 20] });
    return true;
  }
  // Sin polígono disponible: círculo aproximado
  L.circle([lat, lng], { radius: 3000, color: '#3b8fc4', dashArray: '8 6', fillColor: '#7fdcc4', fillOpacity: 0.15 }).addTo(capaLimite);
  map.setView([lat, lng], 13);
  return false;
}

async function resolverLugar(lat, lng, precision) {
  let barrio = 'No identificado', municipio = 'No identificado', direccion = '—';
  try {
    const b = await nominatim(lat, lng, 16, false);
    const a = b.address || {};
    barrio = a.neighbourhood || a.suburb || a.quarter || a.city_district || a.residential || a.hamlet || barrio;
    direccion = b.display_name || direccion;
    $('#d-bar').textContent = barrio;
    $('#d-dir').textContent = direccion;

    await sleep(1100); // Respeta el límite de 1 petición por segundo de Nominatim
    const m = await nominatim(lat, lng, 10, true);
    const am = m.address || {};
    municipio = am.city || am.town || am.village || am.municipality || am.county || am.state_district || municipio;
    $('#d-mun').textContent = municipio;
    const hayLimite = dibujarLimite(m, lat, lng);
    setEstado('ok', `✅ Estás en ${municipio}` + (barrio !== 'No identificado' ? ` · ${barrio}` : '') + (hayLimite ? '' : ' (límite aproximado)'));
  } catch (err) {
    setEstado('err', '⚠️ Tengo tus coordenadas, pero no pude consultar el municipio/barrio. Intenta de nuevo.');
    $('#d-mun').textContent = municipio; $('#d-bar').textContent = barrio;
  }

  if ($('#guardar').checked) {
    fetch(location.pathname, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ csrf: CSRF, lat, lng, precision, municipio, barrio, direccion })
    }).catch(() => {});
  }
}

function onPos(pos) {
  const { latitude: lat, longitude: lng, accuracy } = pos.coords;
  $('#d-lat').textContent = lat.toFixed(6);
  $('#d-lng').textContent = lng.toFixed(6);
  $('#d-pre').textContent = '± ' + Math.round(accuracy) + ' m';
  $('#d-mun').textContent = '…'; $('#d-bar').textContent = '…'; $('#d-dir').textContent = '…';
  setEstado('', '📍 Ubicación encontrada. Consultando municipio y barrio…');

  capaUsuario.clearLayers();
  L.marker([lat, lng], { icon: emojiIcon('📍') }).addTo(capaUsuario).bindPopup('<b>Estás aquí</b>').openPopup();
  L.circle([lat, lng], { radius: accuracy, color: '#59b2e6', fillColor: '#59b2e6', fillOpacity: 0.12, weight: 1 }).addTo(capaUsuario);
  map.setView([lat, lng], 14);

  mostrarCercanos(lat, lng);
  resolverLugar(lat, lng, accuracy);
}

function onErr(err) {
  const msgs = {
    1: 'Permiso de ubicación denegado. Actívalo en tu navegador y pulsa «Escanear ubicación».',
    2: 'No se pudo determinar tu posición. Revisa tu GPS o conexión.',
    3: 'Se agotó el tiempo de espera. Intenta de nuevo.'
  };
  setEstado('err', '⚠️ ' + (msgs[err.code] || 'Error de geolocalización.'));
}

function escanear() {
  if (!('geolocation' in navigator)) { setEstado('err', '⚠️ Tu navegador no soporta geolocalización.'); return; }
  setEstado('', '🔎 Buscando tu ubicación…');
  navigator.geolocation.getCurrentPosition(onPos, onErr, { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 });
}
$('#escanear').addEventListener('click', escanear);
window.addEventListener('load', () => setTimeout(escanear, 800)); // Escaneo automático al abrir la página
</script>
</body>
</html>